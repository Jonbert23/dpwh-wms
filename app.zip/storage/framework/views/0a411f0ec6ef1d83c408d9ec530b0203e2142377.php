<?php $__env->startSection('header'); ?>
    My Task
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="panel panel-default">

        <div class="panel-title">
        My Current Schedule
        </div>

        <div class="panel-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <td>Location</td>
                        <td>Work/Task</td>
                        <td>Start Date</td>
                        <td>End Date</td>
                    </tr>
                </thead>
            <tbody>
                <?php 
                    $sd = '';
                    $ed = '';
                ?>
                <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($tasks->mpp == $mppId): ?>
                        <?php if($tasks->dateFrom <= $dateNow && $tasks->dateTo >= $dateNow): ?>
                            <?php if($sd != $tasks->dateFrom && $ed != $tasks->dateTo): ?>
                                <tr>
                                    <td><?php echo e(\App\Location::find($tasks->location_id)->zoneName); ?> <?php echo e(\App\Location::find($tasks->location_id)->barangayName); ?>, <?php echo e(\App\Location::find($tasks->location_id)->cityName); ?></td>
                                    <td><?php echo e(\App\Work::find($tasks->work_id)->name); ?></td>
                                    <td><?php echo e($tasks->dateFrom); ?></td>
                                    <td><?php echo e($tasks->dateTo); ?></td>
                                </tr> 

                                <?php 
                                    $sd = $tasks->dateFrom;
                                    $ed = $tasks->dateTo;
                                ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
    </div>
</div>

<div class="col-md-12">
    <div class="panel panel-default">

        <div class="panel-title">
        My Past Schedule
        </div>

        <div class="panel-body">
            <table class="table table-bordered table-striped" id="task">
                <thead>
                    <tr>
                        <td>Location</td>
                        <td>Work/Task</td>
                        <td>Start Date</td>
                        <td>End Date</td>
                    </tr>
                </thead>
            <tbody>
                <?php 
                    $sd = '';
                    $ed = '';
                ?>
                <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($tasks->mpp == $mppId): ?>
                        <?php if($tasks->dateTo < $dateNow): ?>
                            <?php if($sd != $tasks->dateFrom && $ed != $tasks->dateTo): ?>
                                <tr>
                                    <td><?php echo e(\App\Location::find($tasks->location_id)->zoneName); ?> <?php echo e(\App\Location::find($tasks->location_id)->barangayName); ?>, <?php echo e(\App\Location::find($tasks->location_id)->cityName); ?></td>
                                    <td><?php echo e(\App\Work::find($tasks->work_id)->name); ?></td>
                                    <td><?php echo e($tasks->dateFrom); ?></td>
                                    <td><?php echo e($tasks->dateTo); ?></td>
                                </tr> 

                                <?php 
                                    $sd = $tasks->dateFrom;
                                    $ed = $tasks->dateTo;
                                ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
    </div>
</div>

  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
    <script>
        $(document).ready(function() 
        {
            $('#task').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.mpp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/mppModule/task.blade.php ENDPATH**/ ?>