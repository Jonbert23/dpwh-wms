<?php $__env->startSection('header'); ?>
    Upload Attendace File
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-12">
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
          <?php endif; ?>
  </div>
</div>

<div class="row">
  <div class="col-lg-12">
      <?php if(session()->has('message')): ?>
          <div class="alert alert-success">
              <?php echo e(session()->get('message')); ?>

          </div>
      <?php endif; ?>
  </div>
</div>


<div class="modal fade" id="dtr" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">DTR Filter</h5>
        
      </div>
      <div class="modal-body">
        <form class="form-horizontal" action="/adminSearchDTR" method="POST">
          <?php echo e(@csrf_field()); ?>

          <div class="form-group">
            <label class="col-sm-2 control-label form-label">Month</label>
            <div class="col-sm-10">
              <select name="month" id="" class="col-md-12">
                <option value="1" <?php if($monthNow == 1): ?> selected <?php endif; ?>>January</option>
                <option value="2"  <?php if($monthNow == 2): ?> selected <?php endif; ?>>Febuary</option>
                <option value="3" <?php if($monthNow == 3): ?> selected <?php endif; ?>>March</option>
                <option value="4"  <?php if($monthNow == 4): ?> selected <?php endif; ?>>April</option>
                <option value="5" <?php if($monthNow == 5): ?> selected <?php endif; ?>>May</option>
                <option value="6" <?php if($monthNow == 6): ?> selected <?php endif; ?>>June</option>
                <option value="7" <?php if($monthNow == 7): ?> selected <?php endif; ?>>July</option>
                <option value="8" <?php if($monthNow == 8): ?> selected <?php endif; ?>>August</option>
                <option value="9" <?php if($monthNow == 9): ?> selected <?php endif; ?>>September</option>
                <option value="10" <?php if($monthNow == 10): ?> selected <?php endif; ?>>October</option>
                <option value="11" <?php if($monthNow == 11): ?> selected <?php endif; ?>>November</option>
                <option value="12" <?php if($monthNow == 12): ?> selected <?php endif; ?>>December</option>
            </select>
            </div>
          </div>
  
          <div class="form-group">
            <label class="col-sm-2 control-label form-label">Year</label>
            <div class="col-sm-10">
              <select name="year" id="" class="col-md-12" >
                <?php for($i = 2015; $i <= $yearNow; $i++): ?>
                <option value="<?php echo e($i); ?>" <?php if($i == $yearNow): ?>selected <?php endif; ?>><?php echo e($i); ?></option>
                <?php endfor; ?>
              </select>
            </div>
          </div>
         
          <div class="form-group">
            <label class="col-sm-2 control-label form-label">Quarter</label>
            <div class="col-sm-10">
              <select name="quarter" class="col-sm-12">
                <option value="1">Date 1-15</option>
                <option value="2">Date 16-31</option>
                <option value="3">Whole Month</option>
              </select>
            </div>
          </div>
       
          <input type="hidden" class="form-control"  name="workerId" id="workerId">
          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" class="btn btn-default btn-block">Submit</button>
            </div>
          </div>

        </form>   
      </div>

      <div class="modal-footer">
        <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



    
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">

      <div class="panel-title">
        View Workers DTR
      </div>

      <div class="panel-body">
        <table class="table table-bordered table-striped" id="DTRIndex">
          <thead>
            <tr>
                <th>Name</th>
                <th>ID Number</th>
                <th>Section</th>
                <th>Skill</th>
                <th>Action</th>
            </tr>
          </thead>
          <tbody class="text-capitalize">
            <?php if($worker): ?>
                <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($workers->role_id == 3): ?>
                        <tr>
                            <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                            <td><?php echo e($workers->idNumber); ?></td>
                            <td><?php echo e($workers->section->name); ?></td>
                            <td><?php echo e($workers->skill->name); ?></td>
                            <td>
                                <button type="button" class="btn btn-default" data-toggle="modal" data-target="#dtr" data-workers="<?php echo e($workers->id); ?>">
                                  View DTR
                                </button>
                            </td>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>  
        </tbody>
        </table>
      </div>
    </div>
  </div>


</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
  <script>
      const realFileBtn = document.getElementById("real-file");
      const customBtn = document.getElementById("custom-button");
      const customTxt = document.getElementById("custom-text");

      customBtn.addEventListener("click", function() 
      {
          realFileBtn.click();
      });

      realFileBtn.addEventListener("change", function() 
      {
          if (realFileBtn.value) 
          {
              customTxt.innerHTML = realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
          } 
          else 
          {
              customTxt.innerHTML = "No file chosen, yet.";
          }
      });
  </script>

  <script>
    $(document).ready(function() {
        $('#DTRIndex').DataTable();
    } );
  </script>

  <script>
    $('#dtr').on('show.bs.modal', function(event)
    {
        var button = $(event.relatedTarget)
        var id = button.data('workers')

        var modal = $(this)
        modal.find('.modal-body  #workerId').val(id)
    })
  </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/admin/attendance/UploadAttendance.blade.php ENDPATH**/ ?>