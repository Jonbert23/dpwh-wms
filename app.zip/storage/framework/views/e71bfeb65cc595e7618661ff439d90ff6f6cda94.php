<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
    .img-resize
    {
        height: 50px;
        width: 50px;
    }
    .dropdown-menu{
      background-color: transparent;
      border: transparent;
      border: none;
    }
    .dropdown-menu .dropdown-item > li > a:hover {
      background-image: none;
      
      background-color: #000!important;
    }

    .navbar {
      background: none;
    }
    .dropdown-content a:hover {
        background-color: transparent;
    }
    .hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Worker Salary Info
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="panel panel-default">

      <div class="panel-title">
        Bordered table
      </div>

      <div class="panel-body">

        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <td rowspan="2"><br>ID</td>
              <td  rowspan="2"><br>Name</td>
              <td  rowspan="2"><br>ID Number</td>
              <td  rowspan="2"><br>Salary/Day</td>
              <td colspan=3 class="text-center">Salary Deduction</td>
              <td rowspan="2"><br>Action</td>
            </tr>
             <tr>
              <td>GSIS</td>
              <td>PAG-IBIG</td>
              <td>PHILHEALTH</td>
            </tr>
          </thead>

          <tbody>
            <?php if($worker): ?>
              <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($workers->role_id == 3): ?>
                  <tr>
                    <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salaries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($workers->id == $salaries->worker_id): ?>
                        <?php $c_salary = $salaries->salaryAmount?>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td class="center"><img class="img-responsive img-rounded img-resize" src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($workers->idPicture); ?>"></td>
                    <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                    <td><?php echo e($workers->idNumber); ?> </td>
                    <td><?php echo e($c_salary); ?></td>
                    <?php $__currentLoopData = $deduction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deduc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($workers->id == $deduc->worker_id): ?>
                        <td><?php echo e($deduc->GSIS); ?></td>
                        <td><?php echo e($deduc->PAGIBIG); ?></td>
                        <td><?php echo e($deduc->PHILHEALTH); ?></td>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <td>
                          <div class="dropdown">
                            <button class="btn btn-info dropdown-toggle" data-toggle="dropdown" > <i class="fa fa-cog fa "> <span class="caret"></span></i></button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                              <div class="col-md-1"></div>
                              <a class="dropdown-item btn btn-default btn-rounded  col-md-12" data-toggle="modal" data-target="#changeSalary" href="#">Change Salary</a>
                              <div class="col-md-1"></div>
                              <a class="dropdown-item btn btn-default btn-rounded col-md-12" data-toggle="modal" data-target="#updateDeduction" href="#">Update Deduction</a>
                              <div class="col-md-1"></div>
                              <a class="dropdown-item btn btn-default  btn-rounded col-md-12"  href="#">View Earnings</a>
                            </div>
                          </div>
                    </td>
                  </tr>

                <?php endif; ?>
               
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/Payroll/PayrollIndex.blade.php ENDPATH**/ ?>