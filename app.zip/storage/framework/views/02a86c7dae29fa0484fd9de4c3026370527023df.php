<?php $__env->startSection('head'); ?>
    <style>
        .img-resize
        {
            height: 450px;
            width: 450px;
            margin: auto;
        }
        .img-resize-c
        {
            height: 200px;
            width: 200px;
            margin: auto;
        }
        hr.hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Worker Contaract Details
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    

    <div class="panel panel-default">
        <div class="panel-title panel-info">
            Active Contracts
        </div>                          
        <div class="panel-body">
        
            <?php if($contract): ?>
            <?php $__currentLoopData = $contract; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contracts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($worker->id == $contracts->worker_id && $now < $contracts->expiryDate): ?>
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-body table-responsive">
                                <table id="contract04" class="table display">
                                    <thead>
                                        <tr>
                                            <th>Duration</th>
                                            <th>Starting date</th>
                                            <th>End date</th>
                                            <th>Remarks</th>
                                        </tr>
                                    </thead>
                                    <tbody>
        
                                        <tr>
                                            <td><?php echo e($contracts->duration); ?> Days</td>
                                            <td><?php echo e($contracts->startingDate); ?></td>
                                            <td><?php echo e($contracts->expiryDate); ?></td>
                                            <td><?php echo e($contracts->expiryDate > $now ? 'Active':'Not Active'); ?></td>
                                        </tr>
        
                                    </tbody>
                                </table>
                                <hr class="hrStyle">
                                <h3>Contract Photo</h3>
                                <div class="col md-12">
                                    <?php $__currentLoopData = $conPhoto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($contracts->id == $cp->contract_id): ?>
                                            <div class="col-md-6">
                                                <img class="img-responsive img-rounded img-resize-c" src="<?php echo e(asset('contract')); ?>/<?php echo e($cp->photo); ?>"> 
                                            </div>
                                        <?php endif; ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?> 
        </div>
    </div>

    <div class="panel panel-default">
        <div class="panel-title panel-danger">
            ExpiredContracts
        </div>                         
        <div class="panel-body">
        
            <?php if($contract): ?>
            <?php $__currentLoopData = $contract; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contracts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($worker->id == $contracts->worker_id && $now > $contracts->expiryDate): ?>
                    <div class="col-md-12">
                        <div class="panel panel-default">
                            <div class="panel-body table-responsive">
                                <table id="contract04" class="table display">
                                    <thead>
                                        <tr>
                                            <th>Duration</th>
                                            <th>Starting date</th>
                                            <th>End date</th>
                                            <th>Remarks</th>
                                            <td>Action</td>
                                        </tr>
                                    </thead>
                                    <tbody>
        
                                        <tr>
                                            <td><?php echo e($contracts->duration); ?> Days</td>
                                            <td><?php echo e($contracts->startingDate); ?></td>
                                            <td><?php echo e($contracts->expiryDate); ?></td>
                                            <td><?php echo e($contracts->expiryDate > $now ? 'Active':'Not Active'); ?></td>
                                            <td>
                                                <a href="/edit/contract/<?php echo e($contracts->worker->id); ?>/<?php echo e($contracts->id); ?>">
                                                    <button type="button" class="btn btn-default btn-icon ">
                                                        <i class="fa fa-edit"></i>
                                                    </button>
                                                </a>
                                            </td>
        
                                        </tr>
        
                                    </tbody>
                                </table>
                                <hr class="hrStyle">
                                <h3>Contract Photo</h3>
                                <div class="col md-12">
                                    <?php $__currentLoopData = $conPhoto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($contracts->id == $cp->contract_id): ?>
                                            <div class="col-md-6">
                                                <img class="img-responsive img-rounded img-resize-c" src="<?php echo e(asset('contract')); ?>/<?php echo e($cp->photo); ?>"> 
                                            </div>
                                        <?php endif; ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?> 
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.worker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/workerModule/contract.blade.php ENDPATH**/ ?>