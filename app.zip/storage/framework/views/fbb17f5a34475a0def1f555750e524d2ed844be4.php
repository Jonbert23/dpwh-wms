<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Today's Attendance <br><br>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php if($schedule): ?>
    <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sched): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($sched->dateTo > $now && $sched->dateFrom < $now): ?>
            <?php $n_sched = $n_sched + 1?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

  <?php if($atten): ?>
    <?php $__currentLoopData = $atten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($attens->Date == $now): ?>
        <?php $present = $present + 1?>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>


<div class="row">
  <div class="col-md-12 ">
  <ul class="topstats clearfix  row-even">
      <li class="col-xs-6 col-lg-4">
      <span class="title"> Scheduled Workers </span>
      <h3> <i> <img class="center" src="img/w-icon.png" height="30" alt="logo"></i> - <?php echo e($n_sched); ?></h3>
      
      </li>
      <li class="col-xs-6 col-lg-4">
      <span class="title">Present Workers</span>
      <h3><i> <img class="center" src="img/hr-icon.png" height="40" alt="logo"></i> - <?php echo e($present); ?></h3>
      
      </li>
      <li class="col-xs-6 col-lg-4">
      <span class="title ">Absent Workers</span>
      <h3>  <h3><i> <img class="center" src="img/e-icon.png" height="40" alt="logo"></i> - <?php echo e($n_sched - $present); ?></h3>
      </li>
  </ul>
</div>

<div class="col-md-12">
  <br>
</div>

<div class="col-md-12">
        <div class="panel panel-default">
          <div class="panel-title">
            Date: <?php echo e($now); ?>

          </div>
          <div class="panel-body table-responsive">
            <table class="table table-striped table-bordered">
              <thead>
                <tr>
                  <td>Worker Name</td>
                  <td>Morning Sign In</td>
                  <td>Morning Remarks</td>
                  <td>Morning Sign Out</td>
                  <td>Afternoon Sign In</td>
                  <td>Afternoon Remarks</td>
                  <td>Afternoon Sign Out</td>
                  <td>Total Late Time</td>
                </tr>
              </thead>
              <tbody>
                  <?php if($atten): ?>
                      <?php $__currentLoopData = $atten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($attens->worker->role_id == 3 && $attens->Date == $now): ?>
                              <tr>
                                    <td><?php echo e($attens->worker->firstName); ?> <?php echo e($attens->worker->lastName); ?></td>
                                    <td><?php echo e($attens->morningSignin); ?></td>
                                    <td><?php echo e($attens->morningRemark == 1? 'Late': 'Ontime'); ?></td>
                                    <td><?php echo e($attens->morningSignout == $default? '--:--:--' : $attens->morningSignout); ?></td>
                                    <td><?php echo e($attens->afternoonSignin == $default? '--:--:--' : $attens->afternoonSignin); ?></td>
                                    <td>
                                        <?php if($attens->afternoonSignin == $default): ?>
                                          No Remarks Yet!
                                        <?php endif; ?>

                                        <?php if($attens->afternoonSignin != $default): ?>
                                          <?php if($attens->afternoonRemark == 1): ?>
                                            Late
                                          <?php endif; ?>

                                          <?php if($attens->afternoonRemark == 0): ?>
                                            Ontime
                                          <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($attens->afternoonSignout == $default? '--:--:--' : $attens->afternoonSignout); ?></td>
                                    <td><?php echo e($attens->morningTimeLate + $attens->afternoonTimeLate); ?> Minutes</td>
                              </tr>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/attendance/AttendanceIndex.blade.php ENDPATH**/ ?>