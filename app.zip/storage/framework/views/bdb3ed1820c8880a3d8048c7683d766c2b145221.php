<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
    .img-resize
    {
        height: 50px;
        width: 50px;
    }
    .dropdown-menu{
      background-color: transparent;
      border: transparent;
      border: none;
    }
    .dropdown-menu .dropdown-item > li > a:hover {
      background-image: none;
      
      background-color: #000!important;
    }

    .navbar {
      background: none;
    }
    .dropdown-content a:hover {
        background-color: transparent;
    }
    .hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Leave Workers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="panel panel-default">

      <div class="panel-title">
       Grant Leave
      </div>
      <div class="panel-body">
        <table class="table table-bordered table-striped" id="leaveCreate">
          <thead>
            <tr>
                <td ><br>ID Picture</td>
                <td ><br>Name</td>
                <td ><br>ID Number</td>
                <td>Start Date</td>
                <td>End Date</td>
            </tr>
          </thead>
          <tbody>
            <?php if($worker): ?>
              <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($workers->role_id == 3): ?>
                    <?php $__currentLoopData = $leaveWorker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($workers->id == $lw->worker_id ): ?>
                            <tr>
                                <td class="center"><img class="img-responsive img-rounded img-resize" src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($workers->idPicture); ?>" center></td>
                                <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                                <td><?php echo e($workers->idNumber); ?></td>
                                <td><?php echo e($lw->startDate); ?></td>
                                <td><?php echo e($lw->endDate); ?></td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
    <script>
        $(document).ready(function() 
        {
            $('#leaveCreate').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/admin/leave/laeveIndex.blade.php ENDPATH**/ ?>