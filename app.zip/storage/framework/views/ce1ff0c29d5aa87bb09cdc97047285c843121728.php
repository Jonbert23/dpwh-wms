<?php $__env->startSection('header'); ?>
    Create Schedule
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


  
 <div class="modal fade" id="workModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Add New Work Name</h4>
        </div>
            <div class="modal-body">
                <form action="/adminWork" method="POST">
                    <?php echo e(@csrf_field()); ?>

                    <div class="form-group">
                        <label for="input1" class="form-label">Work Name</label>
                        <input type="text" class="form-control" name="WorkName">
                    </div>
                             
                    <button type="submit" class="btn btn-default pull-right">Submit</button>
                </form>
            </div>
        <div class="modal-footer">
        </div>
      </div>
    </div>
</div>



<div class="modal fade" id="locationModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Add New Location Address</h4>
        </div>
        <div class="modal-body">
            <form action="/adminLocation" method="POST">
                <?php echo e(@csrf_field()); ?>

                <div class="form-group">
                    <label for="input1" class="form-label">Poruk/Zone Name</label>
                    <input type="text" class="form-control"  name="Zone">
                </div>
                <div class="form-group">
                    <label for="input2" class="form-label">Barangay Name</label>
                    <input type="text" class="form-control"  name="Barangay">
                </div>
                <div class="form-group">
                    <label for="input3"  class="form-label">City/Municipality Name</label>
                    <input type="text" class="form-control"  name="CityMunicipality">
                </div>
                <button type="submit" class="btn btn-default pull-right">Submit</button>
            </form>
        </div>
        <div class="modal-footer">
        </div>
      </div>
    </div>
</div>


<div class="row">
    <div class="col-lg-12">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
        <div class="col-lg-12">
          <div class="panel panel-default ">
    
            <div class="panel-title panel-info">
             Create Schedule Form
            </div>
                <div class="panel-body">
                <form method="POST"  action= "/adminSchedule" enctype="multipart/form-data" >
                    <?php echo e(@csrf_field()); ?>

                    <div class="col-lg-12 form-group">
                        <label for="input3"  class="form-label col-sm-11">Task Name</label>

                        <div class="col-sm-11">
                             <select type="text" class="form-control" name="workName" >
                            <option disabled selected>Select Task Name</option>
                            <?php if($work): ?>
                                <?php $__currentLoopData = $work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $works): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($works->id); ?>"><?php echo e($works->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        </div>
                       
                        <button type="button" class="btn btn-default btn-icon col-sm-1" data-toggle="modal" data-target="#workModal">
                            <i class="fa fa-plus"></i>
                        </button>
                    </div>
                   
                    <div class="col-lg-12 form-group">
                        <label for="input3"  class="form-label col-sm-12">Designation</label>

                        <div class="col-sm-11">
                            <select type="text" class="form-control " name="designation" >
                                <option></option>
                                <?php if($location): ?>
                                    <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($locations->id); ?>"><?php echo e($locations->zoneName); ?> <?php echo e($locations->barangayName); ?>, <?php echo e($locations->cityName); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <button type="button" class="btn btn-default btn-icon col-sm-1" data-toggle="modal" data-target="#locationModal">
                            <i class="fa fa-plus"></i>
                        </button>
                    </div>

                    <div class="col-lg-12 form-group">
                        <label for="input3"  class="form-label col-sm-12">MPP</label>
                        <div class="col-sm-12">
                            <select type="text" class="form-control " name="mpp" >
                            <option></option>
                            <?php if($worker): ?>
                                <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($workers->role_id == 2
                                    ): ?>
                                        <option value="<?php echo e($workers->id); ?>"><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?> </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        </div>
                        
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="input3"  class="form-label col-sm-12">Start Date</label>
                        <div class="col-sm-12">
                            <input type="date" class="form-control " name="dateFrom">
                        </div>
                        
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="input3"  class="form-label col-sm-12">End Date</label>
                        <div class="col-sm-12">
                            <input type="date" class="form-control " name="dateTo">
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="panel">
                            <div class="panel-title">
                                Unscheduled Workers
                            </div>
                            <div class="panel-body table-responsive">
                            <table id="select" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Select</th>
                                        <th>Name</th>
                                        <th>ID Number</th>
                                        <th>Skill</th>
                                        <th>Section</th>
                                        <th>Education Attainment</th>
                                    </tr>
                                </thead>     
                                <tbody>
                                    <?php if($worker): ?>
                                        <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($workers->role_id == 3): ?>
                                                <tr>
                                                    <td width="5">
                                                        <div class="col-md-12">
                                                            <div class="col-md-4"></div>
                                                            <div class="col-md-2"><input class="checkbox" type="checkbox"  name="workers[]" value="<?php echo e($workers->id); ?>" > </div>
                                                            <div class="col-md-5"></div>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                                                    <td><?php echo e($workers->idNumber); ?></td>
                                                    <td><?php echo e($workers->skill->name); ?></td>
                                                    <td><?php echo e($workers->section->name); ?></td>
                                                    <td><?php echo e($workers->education->name); ?></td>
                                                </tr> 
                                            <?php endif; ?>  
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>     
                        </div>
                    </div>
                    <div class="col-lg-12 form-group">
                        <button type="submit" class="btn btn-default pull-right btn-lg">Create Schedule</button>
                    </div> 
                  </form>
                    
                </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
<script>      
     $(document).ready(function() {
        $('#select').DataTable();
    } );
</script>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/admin/schedule/ScheduleCreate.blade.php ENDPATH**/ ?>