<?php $__env->startSection('header'); ?>
Update Worker Task
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<div class="row">
        <div class="col-lg-12">
          <div class="panel panel-default ">
    
            <div class="panel-title panel-info">
             Update Task Form
            </div>
                <div class="panel-body">
                <form method="POST"  action= "/hrSchedule/<?php echo e($schedule->id); ?>" enctype="multipart/form-data" >
                    <?php echo e(@csrf_field()); ?>

                    <?php echo e(@method_field('PUT')); ?>


                    <div class="col-lg-12 form-group">
                        <label for="input3"  class="form-label col-sm-12">Worker Name</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control " name="worker" value="<?php echo e($schedule->worker->firstName); ?> <?php echo e($schedule->worker->lastName); ?>" disabled>
                        </div>
                    </div>

                    <div class="col-lg-12 form-group">
                        <label for="input3"  class="form-label col-sm-11">Task Name</label>

                        <div class="col-sm-12">
                             <select type="text" class="form-control" name="task" >
                            
                            <?php if($work): ?>
                                <?php $__currentLoopData = $work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $works): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($works->id); ?>" <?php if($works->name == $schedule->work->name): ?> selected <?php endif; ?>><?php echo e($works->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        </div>
                    </div>
                   
                    <div class="col-lg-12 form-group">
                        <label for="input3"  class="form-label col-sm-12">Designation/Location</label>

                        <div class="col-sm-12">
                            <select type="text" class="form-control " name="designation" >
                               
                                <?php if($location): ?>
                                    <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($locations->id); ?>" <?php if($locations->id = $schedule->location->id): ?> selected <?php endif; ?>><?php echo e($locations->zoneName); ?> <?php echo e($locations->barangayName); ?>, <?php echo e($locations->cityName); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-12 form-group">
                        <label for="input3"  class="form-label col-sm-12">MPP</label>
                        <div class="col-sm-12">
                            <select type="text" class="form-control " name="mpp" >
                      
                            <?php if($worker): ?>
                                <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($workers->role_id == 2): ?>
                                        <option value="<?php echo e($workers->id); ?>" <?php if($workers->id == $schedule->mpp): ?> selected <?php endif; ?>><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?> </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        </div>
                        
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="input3"  class="form-label col-sm-12">Start Date</label>
                        <div class="col-sm-12">
                            <input type="date" class="form-control " name="dateFrom" value="<?php echo e($schedule->dateFrom); ?>">
                        </div>
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="input3"  class="form-label col-sm-12">End Date</label>
                        <div class="col-sm-12">
                            <input type="date" class="form-control " name="dateTo" value="<?php echo e($schedule->dateTo); ?>">
                        </div>
                    </div>

                    
                    <div class="col-lg-12 form-group">
                        <button type="submit" class="btn btn-default pull-right">Update</button>
                    </div> 
                  </form>
                    
                </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.hr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/hr/schedule/ScheduleEdit.blade.php ENDPATH**/ ?>