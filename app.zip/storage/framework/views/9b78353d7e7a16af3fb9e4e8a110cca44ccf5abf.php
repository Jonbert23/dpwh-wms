<?php $__env->startSection('header'); ?>
    Activity Logs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">
        <div class="panel-title">
            Search Worker DTR
        </div>

        <div>
            <div class="panel-body">
                <form class="form-inline" action="/searchLogs" method="POST">
                    <?php echo e(@csrf_field()); ?>

                    <div class="form-group col-md-5">
                        <label class="form-label col-md-3">Enter Date</label>
                        <input type="date" class="form-control col-md-9"  name="searchLog" required="required">
                    </div>
                    <button type="submit" class="btn btn-default">Search</button>
                </form>
            </div>
        </div>
    </div>
</div>




    <div class="col-md-12">
        <div class="panel panel-default">
    
          <div class="panel-title">
            Activity Logs
          </div>
          <div class="panel-body">
            <table class="table table-bordered table-striped" id="leaveCreate">
              <thead>
                <tr>
                    <td>No.</td>
                    <td >Responsible</td>
                    <td >Activity</td>
                    <td >Date</td>
                    <td>Time</td>
                </tr>
              </thead>
              <tbody>
                <?php if($log): ?>
                    <?php $__currentLoopData = $log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $counter = $counter + 1;?>     
                        <tr>
                            <td><?php echo e($counter); ?>.</td>
                            <td ><?php echo e(\App\Worker::find($logs->worker_id)->firstName); ?> <?php echo e(\App\Worker::find($logs->worker_id)->lastName); ?></td>
                            <td><?php echo e($logs->activity); ?></td>
                            <td><?php echo e($logs->date); ?></td>
                            <td><?php echo e($logs->time); ?></td>
                        </tr>     
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
    
        </div>
      </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('jsScript'); ?>
    <script>
        $(document).ready(function() 
        {
            $('#leaveCreate').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/logs/logIndex.blade.php ENDPATH**/ ?>