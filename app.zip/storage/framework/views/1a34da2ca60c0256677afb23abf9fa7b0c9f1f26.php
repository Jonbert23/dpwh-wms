<?php $__env->startSection('head'); ?>
    <style>
        .img-resize
        {
            height: 350px;
            width: 350px;
            margin: auto;
        }
        hr.hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Worker Task
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-md-4 text-center">
    <img class="img-responsive img-rounded img-resize"src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($worker->idPicture); ?>">
    <h3><?php echo e($worker->firstName); ?> <?php echo e($worker->lastName); ?></h3>
    <h5><?php echo e($worker->idNumber); ?></h5>
    <hr class="hrStyle">  
</div>

<div class="col-md-8">
    <div class="panel panel-default">
      <div class="panel-title panel-info">
      Active Task
      </div>
      <div class="panel-body table-responsive">
          <table id="contract04" class="table table-bordered">
              <thead>
                  <tr>
                      <th>Task</th>
                      <th>MPP</th>
                      <th>Location</th>
                      <th>Start Date</th>
                      <th>End Date</th>
                  </tr>
              </thead>     
              <tbody>
                  <?php if($sched): ?>
                    <?php $__currentLoopData = $sched; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scheds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($worker->id == $scheds->worker->id && $scheds->dateTo >= $now): ?> 
                        <tr>
                            <td><?php echo e($scheds->work->name); ?></td>
                            <td>
                                <?php $__currentLoopData = $mpp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mpps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($scheds->mpp == $mpps->id): ?>
                                        <?php echo e($mpps->firstName); ?> <?php echo e($mpps->lastName); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($scheds->location->zoneName); ?> <?php echo e($scheds->location->barangayName); ?>, <?php echo e($scheds->location->cityName); ?></td>
                            <td><?php echo e($scheds->dateFrom); ?></td>
                            <td><?php echo e($scheds->dateTo); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?> 
            </tbody>
          </table>
      </div>
    </div>
  </div>

  <div class="col-md-8">
    <div class="panel panel-default">
      <div class="panel-title panel-danger">
      Past Task/Expired Task
      </div>
      <div class="panel-body table-responsive">
          <table id="contract04" class="table display">
              <thead>
                  <tr>
                      <th>Task</th>
                      <th>MPP</th>
                      <th>Location</th>
                      <th>Start Date</th>
                      <th>End Date</th>
                  </tr>
              </thead>     
              <tbody>
                  <?php if($sched): ?>
                    <?php $__currentLoopData = $sched; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scheds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($worker->id == $scheds->worker->id && $scheds->dateTo <= $now): ?>
                        <tr>
                            <td><?php echo e($scheds->work->name); ?></td>
                            <td>
                                <?php $__currentLoopData = $mpp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mpps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($scheds->mpp == $mpps->id): ?>
                                        <?php echo e($mpps->firstName); ?> <?php echo e($mpps->lastName); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($scheds->location->zoneName); ?> <?php echo e($scheds->location->barangayName); ?>, <?php echo e($scheds->location->cityName); ?></td>
                            <td><?php echo e($scheds->dateFrom); ?></td>
                            <td><?php echo e($scheds->dateTo); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?> 
            </tbody>
          </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/admin/schedule/ScheduleView.blade.php ENDPATH**/ ?>