<?php $__env->startSection('head'); ?>
<style>
    .img-resize
    {
        height: 50px;
        width: 50px;

       
    }
    hr.hrStyle
    {
        border: none;
        border-top: 2px solid;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <h1 class="title">Morning Sign Out</h1>
    <br>
    <ol class="breadcrumb">
        <li><a href="/adminAttendance/create"> Morning Sign In</a></li>
        <li><a href="#">Morning Sign Out</a></li>
        <li><a href="/afternoonSignin/create">Aternoon Sign In</a></li>
        <li><a href="/afternoonSignout/create">Afternoon Sign Out</a></li>
    </ol>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- Start Page Header Right Div -->
  
  <!-- End Page Header Right Div -->

    <div class="row">
        <div class="col-lg-12">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
        </div>
      </div>

      
      <div class="row">
        <div class="col-lg-12">
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
        </div>
      </div>

      <div class="col-md-12">
        <div class="alert alert-info">
            <h4>NOTE</h4>
            <ul>
              <li><label>Sign out time starts at 11:50 AM</label> </li>
              <li><label>Sign out time ends at 12:50 AM</label></li>
            </ul>
        </div>
      </div>

    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          Morning Sign out
        </div>
       
        <div class="panel-body table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <td>ID Picture</td>
                <td>Worker Name</td>
                <td>ID Number</td>
                <td>Action</td>
              </tr>
            </thead>
            <tbody>
                <?php if($atten): ?>
                    <?php $__currentLoopData = $atten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($attens->worker->role_id == 3 && $attens->Date == $dateNow && $attens->morningSignin != $default): ?>
                            <tr>
                              <form action="/morningSignout/<?php echo e($attens->id); ?>" method="POST">
                                    <?php echo e(@csrf_field()); ?>

                                    <?php echo e(@method_field('PUT')); ?>

                                    <td class="center"><img class="img-responsive img-rounded img-resize" src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($attens->worker->idPicture); ?>"></td>
                                    <td><?php echo e($attens->worker->firstName); ?> <?php echo e($attens->worker->lastName); ?></td>
                                    <td><?php echo e($attens->worker->idNumber); ?></td>

                                    <input type="hidden" name="worker_id" value="<?php echo e($attens->worker->id); ?>">

                                    <td>
                                      <?php if($attens->morningSignout != $default): ?>
                                        Already Signed Out!
                                      <?php endif; ?>
                                      
                                      <input value="Sign Out"
                                          <?php if($checkTime > $timeNow): ?>
                                            disabled
                                          <?php endif; ?>
                                          <?php if($endCheckTime < $timeNow): ?>
                                            disabled
                                          <?php endif; ?>
                                          <?php if($attens->morningSignout != $default): ?>
                                            type="hidden" 
                                          <?php endif; ?>
                                          
                                      type="submit" id="msi" class="btn btn-info bnt-icon">
                                    </td>
                                </form>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>

<script>
  if(document.getElementById('msi').clicked == true)
  {
    document.getElementById('msi').disabled== true;
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/attendance/MorningSignoutCreate.blade.php ENDPATH**/ ?>