<?php $__env->startSection('head'); ?>
    <style>
        .img-resize
        {
            height: 450px;
            width: 450px;
            margin: auto;
        }
        hr.hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    View Worker Profile
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="container col-md-5 text-center">
    <img class="img-responsive img-rounded img-resize"src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($findWorker->idPicture); ?>">
    <h1><?php echo e($findWorker->firstName); ?> <?php echo e($findWorker->lastName); ?></h2>
    <hr class="hrStyle">
</div>


<div class="col-md-7">
        <div class="panel panel-default">
          <div class="panel-title">
          Worker Profile Information
          </div>
          <div class="panel-body table-responsive">
              <table id="example0" class="table display">
                  <thead>
                        <tr>
                            <th>ID Number</th>
                            <th><?php echo e($findWorker->idNumber); ?></th>
                        </tr>
                    </thead> 
                  <thead>
                    <tr>
                        <th>Gender</th>
                        <th><?php echo e($findWorker->gender); ?></th>
                    </tr>
                </thead> 
                <thead>
                    <tr>
                        <th>Contact Number</th>
                        <th><?php echo e($findWorker->contactNumber); ?></th>
                    </tr>
                </thead>    
                <thead>
                    <tr>
                        <th>Skill</th>
                        <th><?php echo e($findWorker->skill->name); ?></th>
                    </tr>
                </thead>
                <thead>
                    <tr>
                        <th>Section</th>
                        <th><?php echo e($findWorker->section->name); ?></th>
                    </tr>
                </thead>
                <thead>
                    <tr>
                        <th>Education</th>
                        <th><?php echo e($findWorker->education->name); ?></th>
                    </tr>
                </thead>
                <thead>
                    <tr>
                        <th>Address</th>
                        <th><?php echo e($findWorker->address); ?></th>
                    </tr>
                </thead>
                <thead>
                    <tr>
                        <th>Role</th>
                        <th><?php echo e($findWorker->role->name); ?></th>
                    </tr>
                </thead>
                <thead>
                    <tr>
                        <th>Status</th>
                        <th><?php echo e($findWorker->status==1?'Employed':'Unemployed'); ?></th>
                    </tr>
                </thead>
              </table>
          </div>
        </div>
      </div>    
<?php $__env->stopSection(); ?>




<?php $__env->startSection('jsScript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/worker/view.blade.php ENDPATH**/ ?>