<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
    .img-resize
    {
        height: 50px;
        width: 50px;
    }
    .dropdown-menu{
      background-color: transparent;
      border: transparent;
      border: none;
    }
    .dropdown-menu .dropdown-item > li > a:hover {
      background-image: none;
      
      background-color: #000!important;
    }

    .navbar {
      background: none;
    }
    .dropdown-content a:hover {
        background-color: transparent;
    }
    .hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Worker Earnings Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-12">
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
          <?php endif; ?>
  </div>
</div>

<div class="row">
  <div class="col-lg-12">
      <?php if(session()->has('message')): ?>
          <div class="alert alert-success">
              <?php echo e(session()->get('message')); ?>

          </div>
      <?php endif; ?>
  </div>
</div>

 <!-- Modal -->
 <div class="modal fade" id="c_code" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <span class="modal-title" id="exampleModalLabel">Code Confirmation</span>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/adminPayroll" method="POST" >
        <?php echo e(@csrf_field()); ?>

        <div class="modal-body">  
          <div class="form-group">
            <label for="example1" class="form-label">Worker Confirmation Code</label>
            <input type="text" class="form-control" name="c_code" >
            
          </div> 
          <div class="form-group">
            <input type="hidden" class="form-control" id="worker" name="workerId">
            <input type="hidden" class="form-control" id="netSalary" name="netSalary">
            <input type="hidden" class="form-control" value="<?php echo e($monthNow); ?>" name="month" >
            <input type="hidden" class="form-control" value="<?php echo e($yearNow); ?>" name="year">
          </div>  
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-default pull-right">OK</button>
        </div>
    </form>
    </div>
  </div>
</div>

    <div class="row">
        <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-title">
            Search for Unpaid Salaries
            </div>
                <div class="panel-body">
                <form class="form-inline" action="/payrollSearch" method="POST">
                    <?php echo e(@csrf_field()); ?>

                    <div class="form-group col-md-5">
                        <label class="form-label col-md-2">Month</label>
                        <select name="month" id="" class="col-md-8">
                            <option value="1" <?php if($monthNow == 1): ?> selected <?php endif; ?>>January</option>
                            <option value="2"  <?php if($monthNow == 2): ?> selected <?php endif; ?>>Febuary</option>
                            <option value="3" <?php if($monthNow == 3): ?> selected <?php endif; ?>>March</option>
                            <option value="4"  <?php if($monthNow == 4): ?> selected <?php endif; ?>>April</option>
                            <option value="5" <?php if($monthNow == 5): ?> selected <?php endif; ?>>May</option>
                            <option value="6" <?php if($monthNow == 6): ?> selected <?php endif; ?>>June</option>
                            <option value="7" <?php if($monthNow == 7): ?> selected <?php endif; ?>>July</option>
                            <option value="8" <?php if($monthNow == 8): ?> selected <?php endif; ?>>August</option>
                            <option value="9" <?php if($monthNow == 9): ?> selected <?php endif; ?>>September</option>
                            <option value="10" <?php if($monthNow == 10): ?> selected <?php endif; ?>>October</option>
                            <option value="11" <?php if($monthNow == 11): ?> selected <?php endif; ?>>November</option>
                            <option value="12" <?php if($monthNow == 12): ?> selected <?php endif; ?>>December</option>
                        </select>
                    </div>
                    <div class="form-group col-md-5">
                        <label class="form-label col-md-2">Year</label>
                        <select name="year" id="" class="col-md-8" >
                            <?php for($i = 2010; $i <= $yearNow; $i++): ?>
                              <option value="<?php echo e($i); ?>" <?php if($i == $yearNow): ?>selected <?php endif; ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <input type="hidden" class="form-control"  name="workerId">
                    <button type="submit" class="btn btn-default">Search</button>
                </form>
            </div>
        </div>
    </div>
  <div class="col-md-12">
    <div class="panel panel-default">

      <div class="panel-title">
        Workers Earning of  
        <?php if($monthNow == 12): ?>
        <span class="wname">December, <?php echo e($yearNow); ?> </span>  
        <?php endif; ?>

        <?php if($monthNow == 11): ?>
        <span class="wname">November, <?php echo e($yearNow); ?> </span>
        <?php endif; ?>

        <?php if($monthNow == 10): ?>
        <span class="wname"> October, <?php echo e($yearNow); ?> </span>
        <?php endif; ?>

        <?php if($monthNow == 9): ?>
        <span class="wname">  September, <?php echo e($yearNow); ?> </span>
        
        <?php endif; ?>

        <?php if($monthNow == 8): ?>
        <span class="wname"> August, <?php echo e($yearNow); ?> </span>
        
        <?php endif; ?>

        <?php if($monthNow== 7): ?>
        <span class="wname">   July, <?php echo e($yearNow); ?> </span>
      
        <?php endif; ?>

        <?php if($monthNow== 6): ?>
        <span class="wname"> June, <?php echo e($yearNow); ?></span>
        
        <?php endif; ?>

        <?php if($monthNow == 5): ?>
        <span class="wname">  May, <?php echo e($yearNow); ?> </span>
      
        <?php endif; ?>

        <?php if($monthNow == 4): ?>
        <span class="wname">  April, <?php echo e($yearNow); ?> </span>
      
        <?php endif; ?>

        <?php if($monthNow == 3): ?>
        <span class="wname">March, <?php echo e($yearNow); ?> </span>
        
        <?php endif; ?>

        <?php if($monthNow == 2): ?>
        <span class="wname">Febuary, <?php echo e($yearNow); ?> </span>
        
        <?php endif; ?>

        <?php if($monthNow == 1): ?>
        <span class="wname">  January, <?php echo e($yearNow); ?> </span>
        <?php endif; ?>
      </div>

      <div class="panel-body">

        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <td rowspan="2">ID Picture</td>
              <td rowspan="2">Name</td>
              <td rowspan="2">ID Number</td>
              <td rowspan="2">Earning</td>
              <td colspan="3" class="text-center">Deduction</td>
              <td rowspan="2">Net Salary</td>
              <td rowspan="2">Action</td>
            </tr>
            <tr>
              <td>GSIS</td>
              <td>PAG-IBIG</td>
              <td>PHILHEALTH</td>
            </tr>
          </thead>

          <tbody>
            <?php if($worker): ?>
            <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($workers->role_id == 3): ?>
            
              <tr>
                <td class="center"><img class="img-responsive img-rounded img-resize" src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($workers->idPicture); ?>"></td>
                <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                <td><?php echo e($workers->idNumber); ?> </td>

                <?php $__currentLoopData = $earning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($workers->id == $earn->worker_id && $monthNow == \Carbon\Carbon::createFromFormat('Y-m-d', $earn->date)->month && $yearNow == \Carbon\Carbon::createFromFormat('Y-m-d', $earn->date)->year): ?> 
                    <?php $myEarning = $myEarning + $earn->earningAmount?>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <td>P <?php echo e($myEarning); ?></td>
                <?php $__currentLoopData = $deduction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deduc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($workers->id == $deduc->worker_id): ?>
                    <td>P <?php echo e($deduc->GSIS); ?></td>
                    <td>P <?php echo e($deduc->PAGIBIG); ?></td>
                    <td>P <?php echo e($deduc->PHILHEALTH); ?></td>
                    <?php $totalDeduction = $deduc->GSIS + $deduc->PAGIBIG + $deduc->PHILHEALTH?>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td>P <?php echo e($myEarning - $totalDeduction); ?></td>
                <?php $__currentLoopData = $earning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($workers->id == $earn->worker_id && $monthNow == \Carbon\Carbon::createFromFormat('Y-m-d', $earn->date)->month && $yearNow == \Carbon\Carbon::createFromFormat('Y-m-d', $earn->date)->year && $earn->remark == 0): ?> 
                    <?php $buttonTrigger = $myEarning + $earn->earningAmount?>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($buttonTrigger == 0): ?>
                  <td>Paid</td>
                <?php else: ?>
                <td><input type="submit" value="Pay" class="btn btn-info" data-toggle="modal" data-target="#c_code" data-worker="<?php echo e($workers->id); ?>" data-netsalary="<?php echo e($myEarning - $totalDeduction); ?>"></td>
                <?php endif; ?>
                
              </tr>
            <?php endif; ?>
            <?php $myEarning = 0?>
           
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>   

<?php $__env->startSection('jsScript'); ?>
<script>
  $('#c_code').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) 
    var worker = button.data('worker')
    var net = button.data('netsalary')
    
    var modal = $(this)
    modal.find('#worker').val(worker)
    modal.find('#netSalary').val(net)
  })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/Payroll/PayrollSearch.blade.php ENDPATH**/ ?>