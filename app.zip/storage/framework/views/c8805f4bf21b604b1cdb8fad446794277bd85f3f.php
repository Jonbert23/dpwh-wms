<?php $__env->startSection('header'); ?>
    Expiring Contract
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-title panel-info">
      All Registered Contract
      </div>
      <div class="panel-body table-responsive">
          <table id="contract04" class="table display">
              <thead>
                  <tr>
                      <th>Name</th>
                      <th>ID Number</th>
                      <th>Skill</th>
                      <th>Section</th>
                      <th>Duration</th>
                      <th>Epire date</th>
                      <th>Action</th>
                  </tr>
              </thead>     
              <tbody>
                  <?php if($contract): ?>
                    <?php $__currentLoopData = $contract; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contracts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($contracts->remarks == 0): ?>
                        <tr>
                            <td><?php echo e($contracts->worker->firstName); ?> <?php echo e($contracts->worker->lastName); ?></td>
                            <td><?php echo e($contracts->worker->idNumber); ?></td>
                            <td><?php echo e($contracts->worker->skill->name); ?></td>
                            <td><?php echo e($contracts->worker->section->name); ?></td>
                            <td><?php echo e($contracts->duration); ?> Days</td>
                            <td><?php echo e($contracts->expiryDate); ?></td>
                            <td><a href="/create/contract/<?php echo e($contracts->worker->id); ?>" class="btn btn-default" > Give New Contract</a></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?> 
            </tbody>
          </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/contract/ExpiringContract.blade.php ENDPATH**/ ?>