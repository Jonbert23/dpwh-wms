<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    All Registered Contracts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 ">
    <ul class="topstats clearfix  row-even">
        <li class="col-xs-6 col-lg-4">
        <span class="title"> Active Contracts </span>
        <h3> <i> <img class="center" src="img/contract.png" height="40" alt="logo"></i> - <?php echo e($all); ?></h3>
        
        </li>
        <li class="col-xs-6 col-lg-4">
        <span class="title">This Month Expiring Contract</span>
        <h3><i> <img class="center" src="img/expire-contract.png" height="40" alt="logo"></i> - <?php echo e($expire); ?></h3>
        
        </li>
        <li class="col-xs-6 col-lg-4">
        <span class="title ">This Month Registered Contract</span>
        <h3>  <h3><i> <img class="center" src="img/new-contract.png" height="40" alt="logo"></i> - <?php echo e($new); ?></h3>
        </li>
    
    </ul>

</div>

  <div class="col-md-12">
    <div class="panel panel-default">
      
      <div class="panel-body table-responsive">
          <table id="contract04" class="table display">
              <thead>
                  <tr>
                      <th>Name</th>
                      <th>ID Number</th>
                      <th>Skill</th>
                      <th>Section</th>
                      <th>Number of Contract</th>
                  
                      <th>Action</th>
                  </tr>
              </thead>     
              <tbody>
                  <?php if($contract): ?>
                    <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($workers->role_id == 3): ?>
                            <tr>
                                <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></a></td>
                                <td><?php echo e($workers->idNumber); ?></td>
                                <td><?php echo e($workers->skill->name); ?></td>
                                <td><?php echo e($workers->section->name); ?></td>

                                <?php $__currentLoopData = $contract; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contracts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($workers->id == $contracts->worker_id): ?>
                                        <?php $count = $count + 1?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <td><?php echo e($count); ?> Registered Contracts</td>
                                
                                <td>
                                    <a href="/create/contract/<?php echo e($workers->id); ?>">
                                        <button type="button"  class="btn btn-default btn-icon ">
                                            <i class="fa fa-plus"></i>
                                        </button>
                                    </a>
                                    <a href="/adminContract/<?php echo e($workers->id); ?>">
                                        <button type="button"  class="btn btn-default btn-icon ">
                                            <i class="fa fa-eye"></i>
                                        </button>
                                    </a>
                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php $count = 0?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?> 
            </tbody>
          </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('jsScript'); ?>
<script>
    $(document).ready(function() 
    {
        $('#contract04').DataTable();
    } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/contract/ContractIndex.blade.php ENDPATH**/ ?>