<?php $__env->startSection('head'); ?>
 <style>
    .img-resize
    {
      height: 130px;
      width: 130px;
    }
    
    .hrStyle
    {
      border: none;
      border-top: 2px solid;
    }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Worker Earnings Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-title">
      Search for Unpaid Salaries
      </div>
      <div class="panel-body">
        <div class="col-md-2">
          <img class="img-responsive img-rounded img-resize"src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($worker->idPicture); ?>">
        </div>
        <div class="col-md-8">
          <h4>Name : <?php echo e($worker->firstName); ?> <?php echo e($worker->lastName); ?></h4>
          <h4>ID No. : <?php echo e($worker->idNumber); ?></h4>
        </div>
       
      </div>
          
    </div>
  </div>
</div>

    <div class="row">
        <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-title">
            Search for Unpaid Salaries
            </div>
                <div class="panel-body">
                <form class="form-inline" action="/earningDetails" method="POST">
                    <?php echo e(@csrf_field()); ?>


                    <div class="form-group col-md-5">
                        <label class="form-label col-md-2">Month</label>
                        <select name="month" id="" class="col-md-8">
                            <option value="1" <?php if($month == 1): ?> selected <?php endif; ?>>January</option>
                            <option value="2"  <?php if($month == 2): ?> selected <?php endif; ?>>Febuary</option>
                            <option value="3" <?php if($month == 3): ?> selected <?php endif; ?>>March</option>
                            <option value="4"  <?php if($month == 4): ?> selected <?php endif; ?>>April</option>
                            <option value="5" <?php if($month == 5): ?> selected <?php endif; ?>>May</option>
                            <option value="6" <?php if($month == 6): ?> selected <?php endif; ?>>June</option>
                            <option value="7" <?php if($month == 7): ?> selected <?php endif; ?>>July</option>
                            <option value="8" <?php if($month == 8): ?> selected <?php endif; ?>>August</option>
                            <option value="9" <?php if($month == 9): ?> selected <?php endif; ?>>September</option>
                            <option value="10" <?php if($month == 10): ?> selected <?php endif; ?>>October</option>
                            <option value="11" <?php if($month == 11): ?> selected <?php endif; ?>>November</option>
                            <option value="12" <?php if($month == 12): ?> selected <?php endif; ?>>December</option>
                        </select>
                    </div>
                    <div class="form-group col-md-5">
                        <label class="form-label col-md-2">Year</label>
                        <select name="year" id="" class="col-md-8" >
                            <?php for($i = 2010; $i <= $yearNow; $i++): ?>
                              <option value="<?php echo e($i); ?>" <?php if($i == $yearNow): ?>selected <?php endif; ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <input type="hidden" class="form-control"  name="id" value="<?php echo e($worker->id); ?>">
                    <button type="submit" class="btn btn-default">Search</button>
                </form>
            </div>
        </div>
    </div>
<div class="col-md-12">
    <div class="panel panel-default">

      <div class="panel-title">
        <?php echo e($worker->firstName); ?> <?php echo e($worker->lastName); ?> 
        <?php if($month == 12): ?>
        <span class="wname">December, <?php echo e($year); ?> </span>  
        <?php endif; ?>

        <?php if($month == 11): ?>
        <span class="wname">November, <?php echo e($year); ?> </span>
        <?php endif; ?>

        <?php if($month == 10): ?>
        <span class="wname"> October, <?php echo e($year); ?> </span>
        <?php endif; ?>

        <?php if($month == 9): ?>
        <span class="wname">  September, <?php echo e($year); ?> </span>
        
        <?php endif; ?>

        <?php if($month == 8): ?>
        <span class="wname"> August, <?php echo e($year); ?> </span>
        
        <?php endif; ?>

        <?php if($month == 7): ?>
        <span class="wname">   July, <?php echo e($year); ?> </span>
      
        <?php endif; ?>

        <?php if($month == 6): ?>
        <span class="wname"> June, <?php echo e($year); ?></span>
        
        <?php endif; ?>

        <?php if($month == 5): ?>
        <span class="wname">  May, <?php echo e($year); ?> </span>
      
        <?php endif; ?>

        <?php if($month == 4): ?>
        <span class="wname">  April, <?php echo e($year); ?> </span>
      
        <?php endif; ?>

        <?php if($month == 3): ?>
        <span class="wname">March, <?php echo e($year); ?> </span>
        
        <?php endif; ?>

        <?php if($month == 2): ?>
        <span class="wname">Febuary, <?php echo e($year); ?> </span>
        
        <?php endif; ?>

        <?php if($month == 1): ?>
        <span class="wname">  January, <?php echo e($year); ?> </span>
        <?php endif; ?>
      </div>

      <div class="panel-body">

        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <td >Day</td>
              <td>Earn Amount</td>
              <td>Remark</td>
            </tr>
          </thead>

          <tbody>
            <?php for($i = 1; $i <= 31; $i++): ?>
              <?php $__currentLoopData = $earning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($worker->id == $earn->worker_id && $i == \Carbon\Carbon::createFromFormat('Y-m-d', $earn->date)->day && $month == \Carbon\Carbon::createFromFormat('Y-m-d', $earn->date)->month && $year == \Carbon\Carbon::createFromFormat('Y-m-d', $earn->date)->year ): ?>
                  <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($earn->earningAmount); ?></td>
                    <td><?php echo e($earn->remark == 0? 'Not Paid':'Paid'); ?></td>
                    <?php $temp = $i; ?>
                    <?php $counter = $counter + $earn->earningAmount ?>
                  </tr>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <?php if($i != $temp): ?>
              <tr>
                <td><?php echo e($i); ?></td>
                <td>--</td>
                <td>No Earning</td>
              </tr>
              <?php endif; ?>
            <?php endfor; ?>
            <tr>
              <td >Total Earning</td>
              <td colspan="2"> <?php echo e($counter); ?></td>
            </tr>
          </tbody>
        </table>

    
      </div>
    </div>
  </div>





  
<?php $__env->stopSection(); ?>    

























                          
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/Payroll/EarningDetail.blade.php ENDPATH**/ ?>