<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
    .img-resize
    {
        height: 50px;
        width: 50px;
    }
    
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Payment Records
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="col-md-12">
    <div class="panel panel-default">
      
      <div class="panel-body table-responsive">
          <table id="contract04" class="table display">
              <thead>
                  <tr>
                      <th>ID Picture</th>
                      <th>Name</th>
                      <th>ID Number</th>
                      <th>Salary/Day</th>
                      <th>Number of Contract</th>
                  
                      <th>Action</th>
                  </tr>
              </thead>     
              <tbody>
                  <?php if($worker): ?>
                    <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($workers->role_id == 3): ?>
                            <tr>
                                <td class="center"><img class="img-responsive img-rounded img-resize" src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($workers->idPicture); ?>"></td>
                                <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></a></td>
                                <td><?php echo e($workers->idNumber); ?></td>

                                <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($workers->id == $sal->worker_id): ?>
                                        <?php $c_sal = $sal->salaryAmount?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <td><?php echo e($c_sal); ?></td>

                                <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($workers->id == $payments->worker_id): ?>
                                        <?php $count = $count + 1?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <td><?php echo e($count); ?> Payment Record</td>
                                
                                <td>
                                    <form action="/paymentRecordSearch" method="POST">
                                        <?php echo e(@csrf_field()); ?>

                                        <input type="hidden" value="<?php echo e($workers->id); ?>" name="workerId">
                                        <input type="hidden" value="<?php echo e($month); ?>" name="month">
                                        <input type="hidden" value="<?php echo e($year); ?>" name="year">
                                    
                                        <input type="submit"  class="btn btn-default btn-icon " value="View">
                                    </form>
                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php $count = 0?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?> 
            </tbody>
          </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('jsScript'); ?>
<script>
    $(document).ready(function() 
    {
        $('#contract04').DataTable();
    } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/Payroll/PaymentRecord.blade.php ENDPATH**/ ?>