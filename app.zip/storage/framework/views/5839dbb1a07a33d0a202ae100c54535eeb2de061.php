<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
 </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('header'); ?>
    Today's Task 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
        </div>
    </div>

    <?php if($schedule): ?>
        <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sched): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($sched->dateTo > $now && $sched->dateFrom < $now): ?>
                <?php $scheduled = $scheduled + 1?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if($worker): ?>
        <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($workers->status == 1 && $workers->role_id == 3): ?>
                <?php $n_worker = $n_worker + 1?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


    <div class="row">
        <div class="col-md-12 ">
        <ul class="topstats clearfix  row-even">
            <li class="col-xs-6 col-lg-3">
            <span class="title"> Scheduled Workers </span>
            <h3> <i> <img class="center" src="img/schedule.jpg" height="30" ></i> - <?php echo e($scheduled); ?></h3>
            </li>
            <li class="col-xs-6 col-lg-3">
                <span class="title"> Unscheduled Workers </span>
                <h3> <i> <img class="center" src="img/unschedule.png" height="40" alt="logo"></i> - <?php echo e($n_worker - $scheduled); ?> </h3>
                </li>
            <li class="col-xs-6 col-lg-3">
            <span class="title">Task</span>
            <h3><i> <img class="center" src="img/task.png" height="30" alt="logo"></i> - <?php echo e($task); ?></h3>
            
            </li>
            <li class="col-xs-6 col-lg-3">
            <span class="title ">Assigned Location</span>
            <h3>  <h3><i> <img class="center" src="img/location.png" height="30" alt="logo"></i> - <?php echo e($n_loc); ?></h3>
            </li>
        </ul>
    </div>
       

        <div class="col-md-12">
                <div class="panel panel-default">
                    
                    <div class="panel-body table-responsive">
                        <table id="task" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Worker</th>
                                    <th>MPP</th>
                                    <th>Location</th>
                                    <th>Work</th>
                                    <td>Start Date</td>
                                    <td>End Date</td>
                                    <th>Action</th>
                                </tr>
                            </thead>     
                            <tbody>
                                <?php if($schedule && $worker): ?>
                                    <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($schedules->dateFrom <= $now && $schedules->dateTo >= $now): ?>
                                        <tr>
                                            <td><?php echo e($schedules->worker->firstName); ?> <?php echo e($schedules->worker->lastName); ?></td>
                                            <td> 
                                                <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($workers->id == $schedules->mpp): ?>
                                                        <?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                            </td>
                                            <td><?php echo e($schedules->location->zoneName); ?> <?php echo e($schedules->location->barangayName); ?>, <?php echo e($schedules->location->cityName); ?></td>
                                            <td><?php echo e($schedules->work->name); ?></td>
                                            <td><?php echo e($schedules->dateFrom); ?></td>
                                            <td><?php echo e($schedules->dateTo); ?></td>
                                            <td>
                                                <a href="/hrSchedule/<?php echo e($schedules->id); ?>/edit"> 
                                                    <button type="button"  class="btn btn-default btn-icon btn-sm">
                                                        <i class="fa fa-edit"></i>
                                                    </button>
                                                </a>
                                                <a href="/hrSchedule/<?php echo e($schedules->worker->id); ?>"> 
                                                    <button type="button"  class="btn btn-default btn-icon btn-sm">
                                                        <i class="fa fa-eye"></i>
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endif; ?> 
                                       
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>

<script>
    $('#edit').on('show.bs.modal', function(event)
    {
        
        var button = $(event.relatedTarget)
        var name = button.data('name')
        var mpp = button.data('mpp')
        var location = button.data('location')
        var task = button.data('task')
       // var start = buton.data('start')
       // var end = button.data('end')

        var modal = $(this)
        modal.find('.modal-body  #worker').val(name)
        modal.find('.modal-body  #mpp').val(mpp)
        modal.find('.modal-body  #location').val(location)
        modal.find('.modal-body  #task').val(task)
        //modal.find('.modal-body  #start').val(start)
        //modal.find('.modal-body  #end').val(end)
        
    })
</script>

<script>
    $('#workEditModal').on('show.bs.modal', function(event)
    {
        console.log('Hellow Fuckers')
        var button = $(event.relatedTarget)
        var workName = button.data('working')
        var work = button.data('work')

        var modal = $(this)
        modal.find('.modal-body  #working').val(workName)
        modal.find('.modal-body  #work').val(work)
        
    })
</script>
<script>      
     $(document).ready(function() {
        $('#task').DataTable();
    } );
</script> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.hr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/hr/schedule/ScheduleIndex.blade.php ENDPATH**/ ?>