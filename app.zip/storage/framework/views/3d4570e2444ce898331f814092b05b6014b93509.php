<?php $__env->startSection('header'); ?>
    View DTR
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="panel panel-default">
  
          <div class="panel-title">
            View Workers DTR
          </div>
  
          <div class="panel-body">
            <table class="table table-bordered table-striped" id="DTRIndex">
              <thead>
                <tr>
                    <th>Name</th>
                    <th>ID Number</th>
                    <th>Section</th>
                    <th>Skill</th>
                    <th>Action</th>
                </tr>
              </thead>
              <tbody class="text-capitalize">
                <?php if($worker): ?>
                    <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($workers->role_id == 3): ?>
                            <tr>
                                <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                                <td><?php echo e($workers->idNumber); ?></td>
                                <td><?php echo e($workers->section->name); ?></td>
                                <td><?php echo e($workers->skill->name); ?></td>
                                <td>
                                    <a href="/adminshowDTR/<?php echo e($workers->id); ?>"  class="btn btn-default"> View DTR </a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>  
            </tbody>
            </table>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>

    <script>
    $(document).ready(function() {
        $('#DTRIndex').DataTable();
    } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/admin/attendance/DTRIndex.blade.php ENDPATH**/ ?>