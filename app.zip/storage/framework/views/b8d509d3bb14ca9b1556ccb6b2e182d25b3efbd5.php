<?php $__env->startSection('header'); ?>
    All Workers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-lg-12">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
    </div>
</div>

<div class="modal fade" id="dtr" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">View DTR</h4>
        </div>
        <div class="modal-body">
            <form action="/showDtr" method="POST">
                <?php echo e(@csrf_field()); ?>   
                <div class="form-group col-md-6">
                    <label class="form-label">Start Date</label>
                    <input type="date" class="form-control"  name="startDate">
                </div>
                <div class="form-group col-md-6">
                    <label  class="form-label">End Date</label>
                    <input type="date" class="form-control"  name="endDate">
                </div>

                <input type="hidden" class="form-control"  name="workerId" id="workerId">
                <button type="submit" class="btn btn-default pull-right">Submit</button>
            </form>
        </div>
        <div class="modal-footer">
          
        </div>
      </div>
    </div>
</div>

    <div class="col-md-12">
        <div class="panel panel-default ">
          <div class="panel-title panel-info">
            All Rigestered Workers
          </div>
          <div class="panel-body table-responsive">
              <table id="worker" class="table display">
                  <thead>
                      <tr>
                          <th>Name</th>
                          <th>ID Number</th>
                          <th>Section</th>
                          <th>Skill</th>
                          <th>Action</th>
                      </tr>
                  </thead>     
                  <tbody>
                        <?php if($worker): ?>
                            <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($workers->role_id == 3): ?>
                                    <tr>
                                        <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                                        <td><?php echo e($workers->idNumber); ?></td>
                                        <td><?php echo e($workers->section->name); ?></td>
                                        <td><?php echo e($workers->skill->name); ?></td>
                                        <td>
                                            <a href="#">
                                            <button class="btn btn-default" data-toggle="modal" data-target="#dtr" data-workers="<?php echo e($workers->id); ?>">
                                                    View DTR
                                                </button> 
                                            </a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>  
                </tbody>
              </table>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>

    <script>
    $(document).ready(function() {
        $('#worker').DataTable();
    } );
    </script>
    
    <script>
            $('#dtr').on('show.bs.modal', function(event)
            {
                var button = $(event.relatedTarget)
                var id = button.data('workers')
        
                var modal = $(this)
                modal.find('.modal-body  #workerId').val(id)
                
            })
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/attendance/AttendanceDTR.blade.php ENDPATH**/ ?>