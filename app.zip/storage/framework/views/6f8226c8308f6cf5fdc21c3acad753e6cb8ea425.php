<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
    .img-resize
    {
        height: 50px;
        width: 50px;
    }
    .dropdown-menu{
      background-color: transparent;
      border: transparent;
      border: none;
    }
    .dropdown-menu .dropdown-item > li > a:hover {
      background-image: none;
      
      background-color: #000!important;
    }

    .navbar {
      background: none;
    }
    .dropdown-content a:hover {
        background-color: transparent;
    }
    .hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Grant Leave
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12">
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
          <?php endif; ?>
  </div>
</div>

<div class="row">
  <div class="col-lg-12 text-capitalized">
      <?php if(session()->has('message')): ?>
          <div class="alert alert-success">
              <?php echo e(session()->get('message')); ?>

          </div>
      <?php endif; ?>
  </div>
</div>

 <!-- Modal -->
  <div class="modal fade" id="leave" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <span class="modal-title">Grant Leave to </span  > <span class="modal-title" id="name"></span>
        </div>
        <div class="modal-body">
          <form class="form-horizontal" action="/adminStoreLeave" method="POST">
            <?php echo e(@csrf_field()); ?>

            <div class="form-group">
              <label class="col-sm-3 control-label form-label">Start Date</label>
              <div class="col-sm-9">
                <input type="date" class="form-control" name="startDate" required="required">
              </div>
            </div>
           
            <input type="hidden" name="leaveId" id="workerId">

            <div class="form-group">
              <div class="col-sm-offset-3 col-sm-9">
                <button type="submit" class="btn btn-default btn-block">Submit</button>
              </div>
            </div>
          </form>   
        </div>
  
        <div class="modal-footer">
          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


<div class="col-md-12">
    <div class="panel panel-default">

      <div class="panel-title">
       Grant Leave
      </div>

      <div class="panel-body">
        <table class="table table-bordered table-striped" id="leaveCreate">
          <thead>
            <tr>
              <td rowspan="2"><br>ID Picture</td>
              <td rowspan="2"><br>Name</td>
              <td rowspan="2"><br>ID Number</td>
              <td colspan="2" class="text-center">Leave Credit</td>
              <td colspan="2" class="text-center">Avalavility Date</td>
              <td rowspan="2"><br>Action</td>
            </tr>
            <tr>
                <td>Total</td>
                <td>Remaining</td>
                <td>From</td>
                <td>To</td>
              </tr>
          </thead>
          <tbody>
            <?php if($worker): ?>
              <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($workers->role_id == 3): ?>
                 
                    

                    <?php $__currentLoopData = $lc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($workers->id == $leave->worker_id ): ?>
                        <tr>
                            <td class="center"><img class="img-responsive img-rounded img-resize" src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($workers->idPicture); ?>" center></td>
                            <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                            <td><?php echo e($workers->idNumber); ?></td>
                            <td><?php echo e($leave->totalLeave); ?> Hours</td>
                            <td><?php echo e($leave->remainingLeave); ?> Hours</td>
                            <td><?php echo e($leave->startDate); ?></td>
                            <td><?php echo e($leave->endDate); ?></td>
                            <td>
                              <button type="submit" class="btn btn-default" 
                                data-toggle="modal" 
                                data-target="#leave" 
                                data-worker="<?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?>" 
                                data-work = "<?php echo e($leave->id); ?>">
                                Grant Leave
                              </button>
                            </td>
                          </tr>

                            <?php $from = $leave->startDate?>
                            <?php $to = $leave->endDate?>
                            <?php $remaining = $leave->remainingLeave?>
                            <?php $lcId = $leave->id?>
                            <?php $temp = $workers->id?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                <?php endif; ?>
               
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('jsScript'); ?>
<script>
    $(document).ready(function() 
    {
        $('#leaveCreate').DataTable();
    } );
</script>

<script>
    $('#leave').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget) 
      var worker = button.data('worker')
      var workerId = button.data('workers')
      var date = button.data('date')
      var workerKey = button.data('work')
      var to = button.data('to')
      var from = button.data('form')
      var remaining = button.data('remaining')
      var lc = button.data('lc')
      
      var modal = $(this)
      modal.find('#name').text(worker)
      modal.find('#hello').text(workerId)
      modal.find('#workerId').val(workerKey)
      modal.find('#date').val(date)
      modal.find('#from').val(from)
      modal.find('#to').val(to)
      modal.find('#remaining').val(remaining)
      modal.find('#lc').val(lc)
    })
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/admin/leave/leaveCreate.blade.php ENDPATH**/ ?>