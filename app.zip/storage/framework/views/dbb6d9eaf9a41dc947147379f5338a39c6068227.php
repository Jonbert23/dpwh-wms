<?php $__env->startSection('head'); ?>
 <style>
    .img-resize
    {
      height: 130px;
      width: 130px;
    }
    
    .hrStyle
    {
      border: none;
      border-top: 2px solid;
    }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Worker Earnings Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
        <div class="panel-title">
        Search for Unpaid Salaries
        </div>
        <div class="panel-body">
            <div class="col-md-2">
            <img class="img-responsive img-rounded img-resize"src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($worker->idPicture); ?>">
            </div>
            <div class="col-md-8">
                <table class="col-md-7">
                    <thead>
                        <tr>
                            <th><h5>Name</h5></th>
                            <th><h5><?php echo e($worker->firstName); ?> <?php echo e($worker->lastName); ?></h5></th>
                        </tr>
                    </thead>
                    <thead>
                        <tr>
                            <td><h5>ID Number</h5></td>
                            <td><h5><?php echo e($worker->idNumber); ?></h5></td>
                        </tr>
                    </thead>
                    <thead>
                        <tr>
                            <td><h5>Salary/Day</h5> </td>
                            <td><h5><?php echo e($c_sal); ?></h5></td>
                        </tr>
                    </thead>
                </table>
            </div>
        
        </div>
            
        </div>
    </div>
    </div>

    <div class="row">
        <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-title">
            Search for Payment Records
            </div>
                <div class="panel-body">
                <form class="form-inline" action="/paymentRecordSearch" method="POST">
                    <?php echo e(@csrf_field()); ?>


                    <div class="form-group col-md-5">
                        <label class="form-label col-md-2">Month</label>
                        <select name="month" id="" class="col-md-8">
                            <option value="1" <?php if($month == 1): ?> selected <?php endif; ?>>January</option>
                            <option value="2"  <?php if($month == 2): ?> selected <?php endif; ?>>Febuary</option>
                            <option value="3" <?php if($month == 3): ?> selected <?php endif; ?>>March</option>
                            <option value="4"  <?php if($month == 4): ?> selected <?php endif; ?>>April</option>
                            <option value="5" <?php if($month == 5): ?> selected <?php endif; ?>>May</option>
                            <option value="6" <?php if($month == 6): ?> selected <?php endif; ?>>June</option>
                            <option value="7" <?php if($month == 7): ?> selected <?php endif; ?>>July</option>
                            <option value="8" <?php if($month == 8): ?> selected <?php endif; ?>>August</option>
                            <option value="9" <?php if($month == 9): ?> selected <?php endif; ?>>September</option>
                            <option value="10" <?php if($month == 10): ?> selected <?php endif; ?>>October</option>
                            <option value="11" <?php if($month == 11): ?> selected <?php endif; ?>>November</option>
                            <option value="12" <?php if($month == 12): ?> selected <?php endif; ?>>December</option>
                        </select>
                    </div>

                    <div class="form-group col-md-5">
                        <label class="form-label col-md-2">Year</label>
                        <select name="year" id="" class="col-md-8" >
                            <?php for($i = 2010; $i <= $yearNow; $i++): ?>
                              <option value="<?php echo e($i); ?>" <?php if($i == $yearNow): ?>selected <?php endif; ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <input type="hidden" class="form-control"  name="workerId" value="<?php echo e($worker->id); ?>">
                    <button type="submit" class="btn btn-default">Search</button>
                </form>
            </div>
        </div>
    </div>

    
        <div class="col-md-12">
            <div class="panel panel-default ">
                <div class="panel-title text-center">
                    <h3>DPWH Region X - District II</h3>
                    <h5>Pay Slip</h5>
                </div>
                <div class="panel-body">
                   <h5>Worker Name: <label><?php echo e($worker->firstName); ?> <?php echo e($worker->lastName); ?></label></h5>
                   <h5>ID Number: <label><?php echo e($worker->idNumber); ?></label></h5>
                   <h5>Payment for :
                       <label>
                            <?php if($month == 12): ?>
                            <span class="wname">December, <?php echo e($year); ?></span>  
                            <?php endif; ?>
            
                             <?php if($month == 11): ?>
                             <span class="wname">November, <?php echo e($year); ?></span>
                            <?php endif; ?>
            
                             <?php if($month == 10): ?>
                             <span class="wname"> October, <?php echo e($year); ?></span>
                            <?php endif; ?>
            
                             <?php if($month == 9): ?>
                             <span class="wname">  September, <?php echo e($year); ?></span>
                            
                            <?php endif; ?>
            
                             <?php if($month == 8): ?>
                             <span class="wname"> August, <?php echo e($year); ?></span>
                             
                            <?php endif; ?>
            
                             <?php if($month == 7): ?>
                             <span class="wname">   July, <?php echo e($year); ?></span>
                           
                            <?php endif; ?>
            
                            <?php if($month == 6): ?>
                            <span class="wname"> June, <?php echo e($year); ?></span>
                            
                           <?php endif; ?>
            
                            <?php if($month == 5): ?>
                            <span class="wname">  May, <?php echo e($year); ?></span>
                           
                            <?php endif; ?>
            
                             <?php if($month == 4): ?>
                             <span class="wname">  April, <?php echo e($year); ?></span>
                           
                            <?php endif; ?>
            
                             <?php if($month == 3): ?>
                             <span class="wname">March, <?php echo e($year); ?></span>
                             
                            <?php endif; ?>
            
                             <?php if($month == 2): ?>
                             <span class="wname">Febuary, <?php echo e($year); ?></span>
                             
                            <?php endif; ?>
            
                            <?php if($month == 1): ?>
                            <span class="wname">  January, <?php echo e($year); ?></span>

                           <?php endif; ?>
                        </label> 
                    </h5>

                    <table class="table table-bordered table-striped">
                        <thead class="text-center">
                          <tr>
                            <td colspan="2">Earnings</td>
                            <td colspan="2">Deduction</td>                    
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                                <td>Regular Work</td>
                                <td>P <?php echo e($r_earn); ?></td>
                                <td>GSIS</td>
                                <td>p <?php echo e($gsis); ?></td>
                          </tr>
                          <tr>
                            <td></td>
                            <td></td>
                            <td>PHILHEALTH</td>
                            <td>P <?php echo e($ph); ?></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td> PAG-IBIG</td>
                            <td>P <?php echo e($pag_ibig); ?></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td><label>Total Earning</label></td>
                            <td><label>P <?php echo e($r_earn); ?></label> </td>
                            <td><label> Total Deduction</label></td>
                            <td><label>P <?php echo e($totalDeduction); ?></label> </td>
                        </tr>
                        <tr>
                            <td><label></label></td>
                            <td><label></label> </td>
                            <td><label> Net Salary</label></td>
                            <td><label>P <?php echo e($paid); ?></label> </td>
                        </tr>
                        <tr>
                            <td><label>Paid Amount</label></td>
                            <td colspan="3"><label>P <?php echo e($paid); ?></label> </td>
                        </tr>
                        <tr>
                            <td><label>Paid On</label></td>
                            <td colspan="3"><label><?php echo e($paidDate); ?></label> </td>
                            
                        </tr>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>

    
<?php $__env->stopSection(); ?>    

























                          
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/Payroll/PaySlip.blade.php ENDPATH**/ ?>