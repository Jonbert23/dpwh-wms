<?php $__env->startSection('head'); ?>
<style>
        .img-resize
        {
            height: 400px;
            width: 400px;
            margin: auto;
        }
        hr.hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Contract Registration
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12">
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
          <?php endif; ?>
  </div>
  <div class="row">
    <div class="col-lg-12">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
    </div>
  </div>

    <div class="container col-md-5 text-center">
        <img class="img-responsive img-rounded img-resize"src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($worker->idPicture); ?>">
        <h1><?php echo e($worker->firstName); ?> <?php echo e($worker->lastName); ?></h2>
        <hr class="hrStyle">
    </div>
    <div class="col-md-7">
        <div class="panel panel-default">
            <div class="panel-title panel-warning">
              Worker Profile Information
            </div>
            <div class="panel-body table-responsive">
                <table id="example0" class="table display">
                    <thead>
                        <tr>
                            <th>Skill</th>
                            <th><?php echo e($worker->skill->name); ?></th>
                        </tr>
                    </thead>
                    <thead>
                        <tr>
                            <th>Section</th>
                            <th><?php echo e($worker->section->name); ?></th>
                        </tr>
                    </thead>
                    <thead>
                        <tr>
                            <th>Education Attainment</th>
                            <th><?php echo e($worker->education->name); ?></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-7">
      <div class="panel panel-default">
        <div class="panel-title panel-warning">
          Last Registered Contract
        </div>
        <div class="panel-body table-responsive">
            <table id="contract04" class="table display">
                <thead>
                    <tr>
                        <th>Duration</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        
                    </tr>
                </thead>     
                <tbody>
                    <?php if($contract): ?>
                      <?php $__currentLoopData = $contract; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contracts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($contracts->worker_id == $worker->id): ?>
                          <?php $lastD = $contracts->duration?>
                          <?php $lastS = $contracts->startingDate?>
                          <?php $lastE = $contracts->expiryDate?>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($lastD); ?> Days</td>
                        <td><?php echo e($lastS); ?></td>
                        <td><?php echo e($lastE); ?></td>
                      </tr>
                    <?php endif; ?> 
              </tbody>
            </table>
        </div>
      </div>
    </div>

    
    <div class="col-md-7">
            <div class="panel panel-default">
              <div class="panel-title panel-info">
                Contract Registration Form
              </div>
                  <div class="panel-body">
                    <form class="form-horizontal" action="/hrContract" method="POST" enctype="multipart/form-data">
                      <?php echo e(@csrf_field()); ?>

                      
                      <div class="form-group">
                        <label class="col-sm-2 control-label form-label">Start Date</label>
                        <div class="col-sm-10">
                          <input type="date" class="form-control" name="startDate">
                        </div>
                      </div>
      
                      <div class="form-group">
                        <label class="col-sm-2 control-label form-label">End Date</label>
                        <div class="col-sm-10">
                          <input type="date" class="form-control" name="endDate">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-sm-10">
                          <input type="hidden" class="form-control" name="id" value="<?php echo e($worker->id); ?>">
                        </div>
                      </div>

                      <div class="col-md-12">
                        <div class="panel panel-default">
                  
                          <div class="panel-title">
                            Upload Contract Scanned Photo
                          </div>
                              <div class="panel-body">
                                    <div class="form-group col-md-12">
                                        <label class="form-label">Contract Photo 1</label><br>
                                        <input type="file"  id="cp1"  name="cp1" style="display:none" required="required"/>
                                        <button type="button" class="btn btn-success"id="cp1-button"> <i class="fa fa-upload"> Upload Photo</i> </button>
                                        <span class="ml-2" id="cp1-text" >No file chosen, yet.</span>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label class="form-label">Contract Photo 2</label><br>
                                        <input type="file"  id="cp2"  name="cp2" style="display:none" required="required"/>
                                        <button type="button" class="btn btn-success"id="cp2-button"> <i class="fa fa-upload">   Upload Photo</i> </button>
                                        <span class="ml-2" id="cp2-text" >No file chosen, yet.</span>
                                    </div>
                                    
                              </div>
                        </div>
                    </div>

                      <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                          <button type="submit" class="btn btn-default btn-lg pull-right">Regiter Contract</button>
                        </div>
                      </div>
                    </form>
                  </div>
            </div>
          </div>
          
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
  <script>
    const realFileBtn = document.getElementById("cp1");
    const customBtn = document.getElementById("cp1-button");
    const customTxt = document.getElementById("cp1-text");

    const realFileBtn2 = document.getElementById("cp2");
    const customBtn2 = document.getElementById("cp2-button");
    const customTxt2 = document.getElementById("cp2-text");

  
    customBtn.addEventListener("click", function() 
    {
        realFileBtn.click();
    });

    customBtn2.addEventListener("click", function() 
    {
        realFileBtn2.click();
    });

    


    realFileBtn.addEventListener("change", function() 
    {
        if (realFileBtn.value) 
        {
            customTxt.innerHTML = realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
          
        } 
        else 
        {
            customTxt.innerHTML = "No file chosen, yet.";
        }
    });

    realFileBtn2.addEventListener("change", function() 
    {
        if (realFileBtn2.value) 
        {
            customTxt2.innerHTML = realFileBtn2.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
          
        } 
        else 
        {
            customTxt2.innerHTML = "No file chosen, yet.";
            
        }
    });

    
    
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.hr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/hr/contract/ContractCreat.blade.php ENDPATH**/ ?>