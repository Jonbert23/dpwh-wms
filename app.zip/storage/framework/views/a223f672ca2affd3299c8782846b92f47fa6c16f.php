<?php $__env->startSection('head'); ?>
    <style>
        .img-resize
        {
            height: 250px;
            width: 250px;
            margin: auto;
        }
        hr.hrStyle
        {
            border: none;
            border-top: 2px solid;
            margin-top: -10px;
        }
        hr.hrStyle1
        {
            border: none;
            border-top: 1px solid;
            margin-top: -10px;
        }
        .wname
        {
          font-weight: bold; 
        }
    </style>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    DTR
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-body">
          <img class="img-responsive img-rounded img-resize"src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($worker->idPicture); ?>">
          <h2 class="text-center"><?php echo e($worker->firstName); ?> <?php echo e($worker->lastName); ?></h2>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-12">
        <div class="panel panel-default">
          <div class="panel-title">
            Search For DTR
          </div>
              <div class="panel-body">
                <form class="form-inline" action="/showDtr" method="POST">
                  <?php echo e(@csrf_field()); ?>

                  <div class="form-group">
                    <label for="example1" class="form-label">Start Date</label>
                   <input type="date" class="form-control"  name="startDate">
                  </div>
                  <div class="form-group">
                    <label for="example2" class="form-label">End Date</label>
                    <input type="date" class="form-control"  name="endDate">
                  </div>
                  <input type="hidden" class="form-control"  name="workerId" value="<?php echo e($worker->id); ?>">
                  <button type="submit" class="btn btn-default">Search</button>
                </form>
              </div>
        </div>
      </div>


    <div class="col-md-12">
            <div class="panel panel-default">
      
              <div class="panel-title">
                <h1 class="text-center">Daily Time Record</h1>
                <br>
                <h4 >Name: <span class="wname"><?php echo e($worker->firstName); ?> <?php echo e($worker->lastName); ?></span></h4>
                <hr class="hrStyle1">
              <h5 class="text-capitalize"> <em>For the month of 
                <?php if($startMonth == 12): ?>
                <span class="wname">December, <?php echo e($startYear); ?></span>  
                <?php endif; ?>

                 <?php if($startMonth == 11): ?>
                 <span class="wname">November, <?php echo e($startYear); ?></span>
                <?php endif; ?>

                 <?php if($startMonth == 10): ?>
                 <span class="wname"> October, <?php echo e($startYear); ?></span>
                <?php endif; ?>

                 <?php if($startMonth == 9): ?>
                 <span class="wname">  September, <?php echo e($startYear); ?></span>
                
                <?php endif; ?>

                 <?php if($startMonth == 8): ?>
                 <span class="wname"> August, <?php echo e($startYear); ?></span>
                 
                <?php endif; ?>

                 <?php if($startMonth == 7): ?>
                 <span class="wname">   July, <?php echo e($startYear); ?></span>
               
                <?php endif; ?>

                <?php if($startMonth == 6): ?>
                <span class="wname"> June, <?php echo e($startYear); ?></span>
                
               <?php endif; ?>

                <?php if($startMonth == 5): ?>
                <span class="wname">  May, <?php echo e($startYear); ?></span>
               
                <?php endif; ?>

                 <?php if($startMonth == 4): ?>
                 <span class="wname">  April, <?php echo e($startYear); ?></span>
               
                <?php endif; ?>

                 <?php if($startMonth == 3): ?>
                 <span class="wname">March, <?php echo e($startYear); ?></span>
                 
                <?php endif; ?>

                 <?php if($startMonth == 2): ?>
                 <span class="wname">Febuary, <?php echo e($startYear); ?></span>
                 
                <?php endif; ?>

                <?php if($startMonth == 1): ?>
                <span class="wname">  January, <?php echo e($startYear); ?></span>
               
               <?php endif; ?>

              </em>
              </h5>
              <h5 class="text-capitalize"><em>Official Hour of Arrival and Departure</em></h5>
              </div>
      
              <div class="panel-body">
                <table class="table table-bordered table-striped">
                  <thead class="text-center">
                    <tr>
                      <td rowspan="2">Days</td>
                      <td colspan="2">A.M</td>
                      <td colspan="2" >P.M</td>       
                      <td colspan="2">Under Time</td>                   
                    </tr>
                    <tr>
                      <td>Arrival</td>
                      <td>Departure</td>
                      <td>Arrival</td>
                      <td>Departure</td>
                      <td>Hour</td> 
                      <td>Minute</td>                  
                    </tr>
                  </thead>
                  <tbody>
                    <?php for($i = $startDay; $i <= $endDay; $i++): ?>
                   
                        <?php $__currentLoopData = $atten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($attens->worker_id == $id): ?>

                            <?php if($i == \Carbon\Carbon::createFromFormat('Y-m-d', $attens->Date)->day): ?>
                                <tr>
                                  <td><?php echo e($i); ?></td>
                                  <td><?php echo e($attens->morningSignin); ?></td>
                                  <td><?php echo e($attens->morningSignout); ?></td>
                                  <td><?php echo e($attens->afternoonSignin); ?></td>
                                  <td><?php echo e($attens->afternoonSignout); ?></td>
                                  <td><?php echo e($late = (int)(($attens->morningTimeLate + $attens->afternoonTimeLate)/60)); ?></td>
                                  <td><?php echo e(($attens->morningTimeLate + $attens->afternoonTimeLate)%60); ?></td>
                                  <?php $temp = $i; ?>
                              </tr>
                              <?php endif; ?>
                              
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($i != $temp): ?>
                        <tr>
                          <td><?php echo e($i); ?></td>
                          <td>--:--:--</td>
                          <td>--:--:--</td>
                          <td>--:--:--</td>
                          <td>--:--:--</td>
                          <td>--</td>
                          <td>--</td>
                        </tr>
                        <?php endif; ?>
                    <?php endfor; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/attendance/showDTR.blade.php ENDPATH**/ ?>