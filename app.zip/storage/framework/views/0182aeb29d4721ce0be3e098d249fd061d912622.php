<?php $__env->startSection('head'); ?>
    <style>
        hr.hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <div class="row ">
        Register Worker
    </div>
<?php $__env->stopSection(); ?>

    
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>


<div class="row">
    <div class="col-lg-12">
      <div class="panel panel-default ">

        
            <div class="panel-body">
            <form method="POST"  action= "/adminWorker" enctype="multipart/form-data" >
                <?php echo e(@csrf_field()); ?>

                <div class="col-md-12">
                    <h3>Worker Personal Information</h3>
                </div>
                <div class="col-lg-6 form-group">
                    <label for="input1" class="form-label">First Name</label>
                    <input type="text" class="form-control " name="firstName">
                </div>
                <div class="col-lg-6 form-group">
                    <label for="input2" class="form-label">Last Name</label>
                    <input type="text" class="form-control " name="lastName" >
                </div>
                <div class="col-lg-6 form-group">
                    <label for="input3"  class="form-label">ID Number</label>
                    <input type="number" class="form-control " name="idNumber"}>
                </div>
                <div class="col-lg-6 form-group">
                    <label for="input3"  class="form-label">Gender</label>
                    <select type="text" class="form-control " name="gender" >
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="col-lg-6 form-group">
                    <label for="input3"  class="form-label">Contact Number</label>
                    <input type="number" class="form-control " name="contactNumber">
                </div>
                <div class="col-lg-6 form-group">
                    <label for="input3"  class="form-label">Higheist School Attainment</label>
                    <select type="text" class="form-control " name="education">
                        <option ></option>
                        <?php if($education ?? ''): ?>
                            <?php $__currentLoopData = $education ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $educ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($educ->id); ?>"><?php echo e($educ->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-lg-6 form-group">
                    <label for="input3"  class="form-label">Skill</label>
                    <select type="text" class="form-control " name="skill">
                        <option ></option>
                        <?php if($skill): ?>
                            <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skills): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($skills->id); ?>"><?php echo e($skills->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-lg-6 form-group">
                    <label for="input3"  class="form-label">Section</label>
                    <select type="text" class="form-control " name="section">
                        <option ></option>
                        <?php if($section): ?>
                            <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-lg-6 form-group">
                    <label for="input3"  class="form-label">Role</label>
                    <select type="text" class="form-control " name="role" id="roles" onchange="bawal();">
                        <option ></option>
                        <?php if($role): ?>
                            <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($roles->id); ?>"><?php echo e($roles->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-lg-6 form-group">
                    <input type="hidden" class="form-control " name="status" value="1">
                </div>
                
                <div class="col-lg-12 form-group">
                    <label for="input3"  class="form-label">Address</label>
                    <input type="text" class="form-control " name="address">
                </div>

                <div class="col-lg-12 form-group">
                    <label for="input3"  class="form-label ">Upload Wprker ID Picture</label>
                    <input type="file" class="form-control form-control-line " name="idPicture">
                    <br>
                   
                </div>




                <div id="workerOnly">
                    <div class="col-md-12">
                        <hr class="hrStyle">
                        <h3>Worker Contract</h3>
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="input3"  class="form-label">Contract Start Date</label>
                        <input type="date" class="form-control " name="startingDate" id="startDate">
                    </div>
                    <div class="col-lg-6 form-group">
                        <label for="input3"  class="form-label">Contract Expire Date</label>
                        <input type="date" class="form-control " name="expiryDate" id="endDate">
                    </div>

    
                    <div class="col-md-12">
                        <hr class="hrStyle">
                    </div>

                    <div class="col-lg-6 form-group">
                        <h3>Worker Salary Information</h3>
                        <label for="input3"  class="form-label">Salary Amount Per Day</label>
                        <input type="number" class="form-control " name="salary" id="salary">
                    </div>

    

                    <div class="col-lg-6 form-group">
                        <h3>Worker Leave Cridets</h3>
                        <label for="input3"  class="form-label">Number of Leave Cridets/Hour</label>
                        <input type="number" class="form-control " name="leave" id="leave">
                    </div> 
                    
    

                    <div class="col-md-12">
                        <hr class="hrStyle">
                        <h3>Worker Beneficial Monthly Payment</h3>
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="input3"  class="form-label">GSIS</label>
                        <input type="number" class="form-control " name="gsis" id="gsis">
                    </div>   
                    
                    <div class="col-lg-6 form-group">
                        <label for="input3"  class="form-label">PAG-IBIG</label> 
                        <input type="number" class="form-control " name="pagibig" id="pagibig">
                    </div> 

                    <div class="col-lg-6 form-group" >
                        <label for="input3"  class="form-label">PHILHEALTH</label>
                        <input type="number" class="form-control " name="philhealth" id="philhealth">
                        <br>
                        <br>
                    </div> 
                </div>


                <div class="col-lg-12 form-group">
                    <div class="col-md-5"></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-default btn-lg">Register Worker</button></div>
                    <div class="col-md-5"></div>
                </div> 
              </form>
                
            </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
    <script>
        function bawal()
        {
            var d = document.getElementById('roles');
            var sel = d.options[d.selectedIndex].value;

            if(sel == 1 || sel == 2)
            {
                document.getElementById('workerOnly').hidden = true;
            }
            if(sel == 3)
            {
                document.getElementById('workerOnly').hidden = false;
            }
        }
    
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/worker/create.blade.php ENDPATH**/ ?>