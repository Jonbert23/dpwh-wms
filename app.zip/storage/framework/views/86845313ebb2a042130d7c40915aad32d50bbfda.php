<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
    .img-resize
    {
        height: 50px;
        width: 50px;
    }
    .dropdown-menu{
      background-color: transparent;
      border: transparent;
      border: none;
    }
    .dropdown-menu .dropdown-item > li > a:hover {
      background-image: none;
      
      background-color: #000!important;
    }

    .navbar {
      background: none;
    }
    .dropdown-content a:hover {
        background-color: transparent;
    }
    .hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    My Leave
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="panel panel-default">

      <div class="panel-title">
       My Current Leave
      </div>
      <div class="panel-body">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
                <td>Start Date</td>
                <td>End Date</td>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaves): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($leaves->worker_id == $id): ?>
                    <?php if($leaves->startDate <= $dateNow && $leaves->endDate >= $dateNow): ?>
                        <tr>
                            <td><?php echo e($leaves->startDate); ?></td>
                            <td><?php echo e($leaves->endDate); ?></td>
                        </tr>
                    <?php endif; ?>
                   
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default">

      <div class="panel-title">
       My Past Leave
      </div>
      <div class="panel-body">
        <table class="table table-bordered table-striped" id="leaveCreate">
          <thead>
            <tr>
                <td>Start Date</td>
                <td>End Date</td>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaves): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($leaves->worker_id == $id): ?>
                    <?php if($leaves->endDate < $dateNow): ?>
                        <tr>
                            <td><?php echo e($leaves->startDate); ?></td>
                            <td><?php echo e($leaves->endDate); ?></td>
                        </tr>
                    <?php endif; ?>
                   
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
    <script>
        $(document).ready(function() 
        {
            $('#leaveCreate').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.worker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/workerModule/leave.blade.php ENDPATH**/ ?>