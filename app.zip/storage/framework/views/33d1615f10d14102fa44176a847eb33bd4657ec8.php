<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
    .img-resize
    {
        height: 50px;
        width: 50px;
    }
    .dropdown-menu{
      background-color: transparent;
      border: transparent;
      border: none;
    }
    .dropdown-menu .dropdown-item > li > a:hover {
      background-image: none;
      
      background-color: #000!important;
    }

    .navbar {
      background: none;
    }
    .dropdown-content a:hover {
        background-color: transparent;
    }
    .hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Worker Earnings Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-title">
            Search for Unpaid Salaries
            </div>
                <div class="panel-body">
                <form class="form-inline" action="/earningView" method="POST">
                    <?php echo e(@csrf_field()); ?>

                    <div class="form-group col-md-5">
                        <label class="form-label col-md-2">Month</label>
                        <select name="month" id="" class="col-md-8">
                            <option value="1" <?php if($month == 1): ?> selected <?php endif; ?>>January</option>
                            <option value="2"  <?php if($month == 2): ?> selected <?php endif; ?>>Febuary</option>
                            <option value="3" <?php if($month == 3): ?> selected <?php endif; ?>>March</option>
                            <option value="4"  <?php if($month == 4): ?> selected <?php endif; ?>>April</option>
                            <option value="5" <?php if($month == 5): ?> selected <?php endif; ?>>May</option>
                            <option value="6" <?php if($month == 6): ?> selected <?php endif; ?>>June</option>
                            <option value="7" <?php if($month == 7): ?> selected <?php endif; ?>>July</option>
                            <option value="8" <?php if($month == 8): ?> selected <?php endif; ?>>August</option>
                            <option value="9" <?php if($month == 9): ?> selected <?php endif; ?>>September</option>
                            <option value="10" <?php if($month == 10): ?> selected <?php endif; ?>>October</option>
                            <option value="11" <?php if($month == 11): ?> selected <?php endif; ?>>November</option>
                            <option value="12" <?php if($month == 12): ?> selected <?php endif; ?>>December</option>
                        </select>
                    </div>
                    <div class="form-group col-md-5">
                        <label class="form-label col-md-2">Year</label>
                        <select name="year" id="" class="col-md-8" >
                            <?php for($i = 2010; $i <= $yearNow; $i++): ?>
                              <option value="<?php echo e($i); ?>" <?php if($i == $yearNow): ?>selected <?php endif; ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <input type="hidden" class="form-control"  name="workerId">
                    <button type="submit" class="btn btn-default">Search</button>
                </form>
            </div>
        </div>
    </div>
  <div class="col-md-12">
    <div class="panel panel-default">

      <div class="panel-title">
        Workers Earning of  
        <?php if($month == 12): ?>
        <span class="wname">December, <?php echo e($year); ?> </span>  
        <?php endif; ?>

        <?php if($month == 11): ?>
        <span class="wname">November, <?php echo e($year); ?> </span>
        <?php endif; ?>

        <?php if($month == 10): ?>
        <span class="wname"> October, <?php echo e($year); ?> </span>
        <?php endif; ?>

        <?php if($month == 9): ?>
        <span class="wname">  September, <?php echo e($year); ?> </span>
        
        <?php endif; ?>

        <?php if($month == 8): ?>
        <span class="wname"> August, <?php echo e($year); ?> </span>
        
        <?php endif; ?>

        <?php if($month == 7): ?>
        <span class="wname">   July, <?php echo e($year); ?> </span>
      
        <?php endif; ?>

        <?php if($month == 6): ?>
        <span class="wname"> June, <?php echo e($year); ?></span>
        
        <?php endif; ?>

        <?php if($month == 5): ?>
        <span class="wname">  May, <?php echo e($year); ?> </span>
      
        <?php endif; ?>

        <?php if($month == 4): ?>
        <span class="wname">  April, <?php echo e($year); ?> </span>
      
        <?php endif; ?>

        <?php if($month == 3): ?>
        <span class="wname">March, <?php echo e($year); ?> </span>
        
        <?php endif; ?>

        <?php if($month == 2): ?>
        <span class="wname">Febuary, <?php echo e($year); ?> </span>
        
        <?php endif; ?>

        <?php if($month == 1): ?>
        <span class="wname">  January, <?php echo e($year); ?> </span>
        <?php endif; ?>
      </div>

      <div class="panel-body">

        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <td >ID</td>
              <td>Name</td>
              <td>ID Number</td>
              <td>Earning</td>
              <td>Action</td>
            </tr>
          </thead>

          <tbody>
            <?php if($worker): ?>
              <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($workers->role_id == 3): ?>
                  <tr>

                    <td class="center"><img class="img-responsive img-rounded img-resize" src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($workers->idPicture); ?>"></td>
                    <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                    <td><?php echo e($workers->idNumber); ?> </td>

                    <?php $__currentLoopData = $earning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($workers->id == $earn->worker_id && $month ==  \Carbon\Carbon::createFromFormat('Y-m-d', $earn->date)->month && $year ==  \Carbon\Carbon::createFromFormat('Y-m-d', $earn->date)->year): ?> 
                        <?php $counter = $counter + $earn->earningAmount?>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <td>P <?php echo e($counter); ?></td>

                    <form action="/earningDetails" method="POST">
                        <?php echo e(@csrf_field()); ?>

                        <input type="hidden" value="<?php echo e($month); ?>" name="month">
                        <input type="hidden" value="<?php echo e($year); ?>" name="year">
                        <input type="hidden" value="<?php echo e($workers->id); ?>" name="id">
                        <td><button class="btn btn-info"> <i class="fa fa-eye"> Details</i></button></td>
                    </form>
                  </tr>
                <?php endif; ?>
                <?php $counter = 0?>
               
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/Payroll/EarningView.blade.php ENDPATH**/ ?>