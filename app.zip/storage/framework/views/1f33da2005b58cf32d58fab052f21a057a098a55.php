<?php $__env->startSection('head'); ?>
    <style>
        .img-resize
        {
            height: 450px;
            width: 450px;
            margin: auto;
        }
        hr.hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    View Worker Profile
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="container col-md-5 text-center">
    <img class="img-responsive img-rounded img-resize"src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($findWorker->idPicture); ?>">
    <h1><?php echo e($findWorker->firstName); ?> <?php echo e($findWorker->lastName); ?></h2>
    <hr class="hrStyle">
</div>


    <div class="col-md-7">
        <div class="panel panel-default">
          <div class="panel-title">
          Worker Profile Information
          </div>
          <div class="panel-body table-responsive">
              <table id="example0" style="border: none;" class="table display">
                  <thead>
                        <tr >
                            <th>ID Number</th>
                            <th><?php echo e($findWorker->idNumber); ?></th>
                        </tr>
                    </thead> 
                  <thead>
                    <tr>
                        <th>Gender</th>
                        <th><?php echo e($findWorker->gender); ?></th>
                    </tr>
                </thead> 
                <thead>
                    <tr>
                        <th>Contact Number</th>
                        <th><?php echo e($findWorker->contactNumber); ?></th>
                    </tr>
                </thead>    
                <thead>
                    <tr>
                        <th>Skill</th>
                        <th><?php echo e($findWorker->skill->name); ?></th>
                    </tr>
                </thead>
                <thead>
                    <tr>
                        <th>Section</th>
                        <th><?php echo e($findWorker->section->name); ?></th>
                    </tr>
                </thead>
                <thead>
                    <tr>
                        <th>Education</th>
                        <th><?php echo e($findWorker->education->name); ?></th>
                    </tr>
                </thead>

                <thead>
                    <tr>
                        <th>Address</th>
                        <th><?php echo e($workerAdd->zone); ?> <?php echo e($workerAdd->barangay); ?>, <?php echo e($workerAdd->city); ?> <?php echo e($workerAdd->zipCode); ?></th>
                    </tr>
                </thead>
               
                <thead>
                    <tr>
                        <th>Role</th>
                        <th><?php echo e($findWorker->role->name); ?></th>
                    </tr>
                </thead>
                <thead>
                    <tr>
                        <th>Status</th>
                        <th><?php echo e($findWorker->status==1?'Employed':'Unemployed'); ?></th>
                    </tr>
                </thead>
              </table>
          </div>
        </div>
      </div>   

      <div class="col-md-12">
        <div class="panel panel-default">
    
            <div class="panel-title">
                Worker Contract Information
            </div>
    
            <div class="panel-body">
                <table class="table table-bordered table-striped" id="salaryIndex">
                    <thead>
                        <tr>
                            <th>Duration</th>
                            <th>Start Date</th>
                            <th>Expire Date</th>
                            <th>Remark</th>
                        </tr>
                    </thead>
                    <tbody class="text-capitalize">
                        <?php $__currentLoopData = $contract; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contracts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($findWorker->id == $contracts->worker_id): ?>
                                <tr>
                                <td><?php echo e($contracts->duration); ?> Days</td>
                                <td><?php echo e($contracts->startingDate); ?></td>
                                <td><?php echo e($contracts->expiryDate); ?></td>
                                <?php if($dateNow <= $contracts->expiryDate): ?>
                                    <td>Active</td>
                                <?php endif; ?>
                                <?php if($dateNow > $contracts->expiryDate): ?>
                                    <td>Void/Not Active</td>
                                <?php endif; ?>
                               
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="panel panel-default">
    
            <div class="panel-title">
                Worker Salary Information
            </div>
    
            <div class="panel-body">
                <table class="table table-bordered table-striped" id="salaryIndex">
                    <thead>
                        <tr>
                            <th>Register Date</th>
                            <th>Salary Amount</th>
                        </tr>
                    </thead>
                    <tbody class="text-capitalize">
                        <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($findWorker->id == $sal->worker_id): ?>
                                <tr>
                                    <td><?php echo e($sal->date); ?></td>
                                    <td><?php echo e($sal->salaryAmount); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
      
    <div class="col-md-12">
        <div class="panel panel-default">
    
            <div class="panel-title">
                Worker Beneficial Information
            </div>
    
            <div class="panel-body">
                <table class="table table-bordered table-striped" id="salaryIndex">
                    <thead>
                        <tr>
                            <th>Register Date</th>
                            <th>PHILHEALTH</th>
                            <th>GSIS</th>
                            <th>PAG-IBIG</th>
                            <th>Remark</th>
                        </tr>
                    </thead>
                    <tbody class="text-capitalize">
                        <?php $__currentLoopData = $deduction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deductions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($findWorker->id == $deductions->worker_id): ?>
                                <tr>
                                    <td><?php echo e($deductions->date); ?></td>
                                    <td><?php echo e($deductions->PHILHEALTH); ?></td>
                                    <td><?php echo e($deductions->GSIS); ?></td>
                                    <td><?php echo e($deductions->PAGIBIG); ?></td>
                                    <?php if($deductions->status == 1): ?>
                                        <td>Active</td>
                                    <?php endif; ?>
                                    <?php if($deductions->status == 0): ?>
                                        <td>Void/Not Active</td>
                                    <?php endif; ?>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
      
    <div class="col-md-12">
        <div class="panel panel-default">
    
            <div class="panel-title">
                Worker Leave Cridet Information
            </div>
    
            <div class="panel-body">
                <table class="table table-bordered table-striped" id="salaryIndex">
                    <thead>
                        <tr>
                            <th colspan="2" class="text-center">Leave Credit</th>
                            <th colspan="2" class="text-center">Availability Date</th>
                           
                        </tr>
                        <tr>
                            <th>Total</th>
                            <th>Remaining</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                        </tr>
                    </thead>
                    <tbody class="text-capitalize">
                        <?php $__currentLoopData = $leave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaves): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($findWorker->id == $leaves->worker_id): ?>
                                <tr>
                                    <td><?php echo e($leaves->totalLeave); ?></td>
                                    <td><?php echo e($leaves->remainingLeave); ?></td>
                                    <td><?php echo e($leaves->startDate); ?></td>
                                    <td><?php echo e($leaves->endDate); ?></td>
                                    
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
      
    
<?php $__env->stopSection(); ?>




<?php $__env->startSection('jsScript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.hr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/hr/worker/view.blade.php ENDPATH**/ ?>