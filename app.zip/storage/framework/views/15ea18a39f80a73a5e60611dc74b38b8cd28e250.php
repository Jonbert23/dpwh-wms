<?php $__env->startSection('head'); ?>
    <style>
        .img-resize
        {
            height: 450px;
            width: 450px;
            margin: auto;
        }
        .img-resize-c
        {
            height: 200px;
            width: 200px;
            margin: auto;
        }
        hr.hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Update Contract
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="modal fade" id="dtr" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Update Contract Photo</h5>
          
        </div>
        <div class="modal-body">
          <form class="form-horizontal" action="/UpdateContractPhoto" method="POST" enctype="multipart/form-data">
            <?php echo e(@csrf_field()); ?>

            <div class="form-group col-md-12">
                <label class="form-label">Choose Photo to Upload</label><br>
                <input type="file"  id="cp1"  name="cp1" style="display:none" required="required"/>
                <button type="button" class="btn btn-success" id="cp1-button"> <i class="fa fa-upload"> Upload Photo</i> </button>
                <span class="ml-2" id="cp1-text" >No file chosen, yet.</span>
            </div>
           
            <input type="hidden" class="form-control"  name="cp" id="cp">
            <div class="form-group">
              <div class="col-md-12">
                <button type="submit" class="btn btn-default btn-block">Update Photo</button>
              </div>
            </div>
  
          </form>   
        </div>
        <div class="modal-footer">
          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  

<div class="row">
  <div class="col-lg-12">
      <?php if(session()->has('message')): ?>
          <div class="alert alert-success">
              <?php echo e(session()->get('message')); ?>

          </div>
      <?php endif; ?>
  </div>
</div>

<div class="row">
    <div class="col-lg-12">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
    </div>
    <div class="row">
      <div class="col-lg-12">
              <?php if(session()->has('unaccepted')): ?>
              <div class="alert alert-danger">
                  <?php echo e(session()->get('unaccepted')); ?>

              </div>
              <?php endif; ?>
      </div>
  
  </div>
      <div class="container col-md-5 text-center">
          <img class="img-responsive img-rounded img-resize"src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($worker->idPicture); ?>">
          <h1><?php echo e($worker->firstName); ?> <?php echo e($worker->lastName); ?></h2>
          <hr class="hrStyle">
      </div>
      <div class="col-md-7">
          <div class="panel panel-default">
              <div class="panel-title panel-warning">
                Worker Profile Information
              </div>
              <div class="panel-body table-responsive">
                  <table id="example0" class="table display">
                      <thead>
                          <tr>
                              <th>Skill</th>
                              <th><?php echo e($worker->skill->name); ?></th>
                          </tr>
                      </thead>
                      <thead>
                          <tr>
                              <th>Section</th>
                              <th><?php echo e($worker->section->name); ?></th>
                          </tr>
                      </thead>
                      <thead>
                          <tr>
                              <th>Education Attainment</th>
                              <th><?php echo e($worker->education->name); ?></th>
                          </tr>
                      </thead>
                  </table>
              </div>
          </div>
      </div>
  
<div class="col-md-7">
    <div class="panel panel-default">
      <div class="panel-title panel-info">
        Contract Registration Form
      </div>
          <div class="panel-body">
            <form class="form-horizontal" action="/adminContract/<?php echo e($contract->id); ?>" method="POST">
                <?php echo e(@csrf_field()); ?>

                <?php echo e(@methoD_field('PUT')); ?>

              
              <div class="form-group">
                <label class="col-sm-2 control-label form-label">Start Date</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="startDate" value="<?php echo e($contract->startingDate); ?>">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label form-label">End Date</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="endDate" value="<?php echo e($contract->expiryDate); ?>">
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-10">
                  <input type="hidden" class="form-control" name="id" value="<?php echo e($worker->id); ?>">
                  <input type="hidden" class="form-control" name="contractId" value="<?php echo e($contract->id); ?>">
                </div>
              </div>

              

              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-default pull-right">Update Contract</button>
                </div>
              </div>
            </form>
            <hr>
            <h4>Contract Photo</h4>
            <div class="col-md-12">
                <?php $__currentLoopData = $contractphoto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($cp->contract_id == $contract->id ): ?>
                      <div class="col-md-6">
                          <img class="img-responsive img-rounded img-resize-c" src="<?php echo e(asset('contract')); ?>/<?php echo e($cp->photo); ?>">
                          <br>
                          <button type="button" class="btn btn-primary btn-block " data-toggle="modal" data-target="#dtr" data-cp="<?php echo e($cp->id); ?>">
                            Update Photo
                          </button>
                      </div>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">

                </div>
            </div>
          </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
    <script>
        $('#dtr').on('show.bs.modal', function(event)
        {
            var button = $(event.relatedTarget)
            var id = button.data('cp')

            var modal = $(this)
            modal.find('.modal-body  #cp').val(id)
        })
    </script>

<script>
    const realFileBtn = document.getElementById("cp1");
    const customBtn = document.getElementById("cp1-button");
    const customTxt = document.getElementById("cp1-text");

    customBtn.addEventListener("click", function() 
    {
        realFileBtn.click();
    });

    realFileBtn.addEventListener("change", function() 
    {
        if (realFileBtn.value) 
        {
            customTxt.innerHTML = realFileBtn.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
          
        } 
        else 
        {
            customTxt.innerHTML = "No file chosen, yet.";
        }
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/admin/contract/ContractEdit.blade.php ENDPATH**/ ?>