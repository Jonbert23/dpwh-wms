<?php $__env->startSection('head'); ?>
    <style>
        .img-resize
        {
            height: 450px;
            width: 450px;
            margin: auto;
        }
        hr.hrStyle
        {
            border: none;
            border-top: 2px solid;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    View Worker Profile
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="container col-md-5 text-center">
    <img class="img-responsive img-rounded img-resize"src="<?php echo e(asset('img/Worker ID')); ?>/<?php echo e($worker->idPicture); ?>">
    <h3><?php echo e($worker->firstName); ?> <?php echo e($worker->lastName); ?></h3>
    <h5><?php echo e($worker->idNumber); ?></h5>
    <hr class="hrStyle">  
</div>

<div class="col-md-7">
    <div class="panel panel-default">
      <div class="panel-title panel-info">
        Active Contracts
      </div>
      <div class="panel-body table-responsive">
          <table id="contract04" class="table display">
              <thead>
                  <tr>
                      <th>Duration</th>
                      <th>Starting date</th>
                      <th>End date</th>
                      <th>Remarks</th>
                      <td>Action</td>
                  </tr>
              </thead>     
              <tbody>
                  <?php if($contract): ?>
                    <?php $__currentLoopData = $contract; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contracts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($worker->id == $contracts->worker->id && $now < $contracts->expiryDate): ?>
                        <tr>
                            <td><?php echo e($contracts->duration); ?> Days</td>
                            <td><?php echo e($contracts->startingDate); ?></td>
                            <td><?php echo e($contracts->expiryDate); ?></td>
                            <td><?php echo e($contracts->expiryDate > $now ? 'Active':'Not Active'); ?></td>
                            <td>
                                <a href="/edit/contract/<?php echo e($contracts->worker->id); ?>/<?php echo e($contracts->id); ?>">                                
                                    <button type="button"  class="btn btn-default btn-icon ">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                </a>
                            </td>
                            
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?> 
            </tbody>
          </table>
      </div>
    </div>
  </div>

  <div class="col-md-7">
    <div class="panel panel-default">
      <div class="panel-title panel-danger">
        Expired Contracts
      </div>
      <div class="panel-body table-responsive">
          <table id="contract04" class="table display">
              <thead>
                  <tr>
                      <th>Duration</th>
                      <th>Starting date</th>
                      <th>End date</th>
                      <th>Remarks</th>
                  </tr>
              </thead>     
              <tbody>
                  <?php if($contract): ?>
                    <?php $__currentLoopData = $contract; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contracts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($worker->id == $contracts->worker->id && $now > $contracts->expiryDate): ?>
                        <tr>
                            <td><?php echo e($contracts->duration); ?> Days</td>
                            <td><?php echo e($contracts->startingDate); ?></td>
                            <td><?php echo e($contracts->expiryDate); ?></td>
                            <td><?php echo e($contracts->expiryDate > $now ? 'Active':'Not Active'); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?> 
            </tbody>
          </table>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/contract/ContractView.blade.php ENDPATH**/ ?>