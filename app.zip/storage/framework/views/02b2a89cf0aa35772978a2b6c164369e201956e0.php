<?php $__env->startSection('header'); ?>
    Register Contract
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-title  panel-warning">
        Registered Workers with no contract
      </div>
      <div class="panel-body table-responsive">
          <table id="contract01" class="table display">
              <thead>
                  <tr>
                      <th>Name</th>
                      <th>ID Number</th>
                      <th>Skill</th>
                      <th>Section</th>
                      <th>Eduaction Attainment</th>
                      <th>Action</th>
                  </tr>
              </thead>     
              <tbody>
                <?php if($worker  && $contract): ?>
                    <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($workers->role->name == "Worker" ): ?>
                            <tr>
                                <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                                <td><?php echo e($workers->idNumber); ?></td>
                                <td><?php echo e($workers->skill->name); ?></td>
                                <td><?php echo e($workers->section->name); ?></td>
                                <td><?php echo e($workers->education->name); ?></td>
                                <td><a href="/create/contract/<?php echo e($workers->id); ?>" class="btn btn-default " > Give Contract</a></td>
                            </tr> 
                        <?php endif; ?>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?> 

                

            </tbody>
          </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>
<script>
    $(document).ready(function() 
    {
         $('#contract01').DataTable();
    } );
</script> 
<script>
    $(document).ready(function() 
    {
        $('#contract02').DataTable();
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone2\resources\views/admin/contract/RegisterContract.blade.php ENDPATH**/ ?>