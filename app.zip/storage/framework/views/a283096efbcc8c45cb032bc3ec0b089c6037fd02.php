<?php $__env->startSection('head'); ?>
 <style>
    .row-even {
    background-color:#9bdcde;
    }
    .row-odd {
    background-color:#BDE3FB;
    }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    All Registered Workers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   
    <div class="row">
        <div class="col-md-12 ">
        <ul class="topstats clearfix  row-even">
            <li class="col-xs-6 col-lg-4">
            <span class="title"> Total Number of Worker </span>
            <h3> <i> <img class="center" src="img/w-icon.png" height="30" alt="logo"></i> - <?php echo e($labor); ?></h3>
            
            </li>
            <li class="col-xs-6 col-lg-4">
            <span class="title">Total Number of Admin</span>
            <h3><i> <img class="center" src="img/hr-icon.png" height="40" alt="logo"></i> - <?php echo e($admin); ?></h3>
            
            </li>
            <li class="col-xs-6 col-lg-4">
            <span class="title ">Total Number of MPP</span>
            <h3>  <h3><i> <img class="center" src="img/e-icon.png" height="40" alt="logo"></i> - <?php echo e($mpp); ?></h3>
            </li>
        </ul>
    </div>

    <div class="col-md-12">
        <br>
    </div>
   
    <div class="col-md-12">
        <div class="panel panel-default ">
          
          <div class="panel-body table-responsive">
              <table id="worker" class="table display">
                  <thead>
                      <tr>
                          <th>Name</th>
                          <th>ID Number</th>
                          <th>Section</th>
                          <th>Skill</th>
                          <th>Status</th>
                          <th>Role</th>
                          <th>Action</th>
                      </tr>
                  </thead>     
                  <tbody>
                        <?php if($worker): ?>
                            <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($workers->firstName); ?> <?php echo e($workers->lastName); ?></td>
                                <td><?php echo e($workers->idNumber); ?></td>
                                <td><?php echo e($workers->section->name); ?></td>
                                <td><?php echo e($workers->skill->name); ?></td>
                                <td><?php echo e($workers->status == 1?'Employed':'Unemployed'); ?></td>
                                <td><?php echo e($workers->role->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('adminWorker.edit', $workers->id)); ?>">
                                        <button class="btn btn-default btn-icon ">
                                            <i class="fa fa-edit"></i>
                                        </button> 
                                    </a>
                                    
                                     <a href="/adminWorker/<?php echo e($workers->id); ?>">
                                        <button class="btn btn-default btn-icon ">
                                            <i class="fa fa-eye"></i>
                                        </button> 
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>  
                </tbody>
              </table>
          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsScript'); ?>

    <script>
    $(document).ready(function() {
        $('#worker').DataTable();
    } );
    </script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('MasterTemplate.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalCapstone\resources\views/admin/worker/index.blade.php ENDPATH**/ ?>