<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeaveWorker extends Model
{
    public $timestamps = false;
}
